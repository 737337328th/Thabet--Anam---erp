import os, hashlib, secrets, csv, io, re, unicodedata, time, json, pathlib
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics
from datetime import datetime, timedelta, timezone
from typing import Any
import jwt
from fastapi import FastAPI, HTTPException, Depends, Header, UploadFile, File, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, String, Integer, Boolean, DateTime, Float, ForeignKey, Text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker, Session

APP_VERSION='4.0.0'
DB_URL=os.getenv('DATABASE_URL','sqlite:///./thabet_anam.db')
engine=create_engine(DB_URL, connect_args={'check_same_thread':False} if DB_URL.startswith('sqlite') else {})
SessionLocal=sessionmaker(bind=engine, autoflush=False, autocommit=False)
SECRET=os.getenv('THABET_SECRET','change-this-secret-before-production')
ALLOWED_ORIGINS=[x.strip() for x in os.getenv('ALLOWED_ORIGINS','*').split(',') if x.strip()]
LOGIN_WINDOW=300
LOGIN_MAX_ATTEMPTS=8
_login_attempts={}

def _rate_key(ip, username): return f'{ip}:{username.lower().strip()}'
def _check_login_rate(ip, username):
    now=time.time(); key=_rate_key(ip,username); hits=[t for t in _login_attempts.get(key,[]) if now-t<LOGIN_WINDOW]; _login_attempts[key]=hits
    if len(hits)>=LOGIN_MAX_ATTEMPTS: raise HTTPException(429,'محاولات دخول كثيرة. حاول لاحقًا')
def _record_login_failure(ip, username):
    now=time.time(); key=_rate_key(ip,username); _login_attempts[key]=[t for t in _login_attempts.get(key,[]) if now-t<LOGIN_WINDOW]+[now]
def _clear_login_failures(ip, username): _login_attempts.pop(_rate_key(ip,username),None)

class Base(DeclarativeBase): pass
class Setting(Base):
    __tablename__='settings'; key:Mapped[str]=mapped_column(String(100),primary_key=True); value:Mapped[str]=mapped_column(Text)
class Module(Base):
    __tablename__='modules'; key:Mapped[str]=mapped_column(String(80),primary_key=True); name:Mapped[str]=mapped_column(String(120)); enabled:Mapped[bool]=mapped_column(Boolean,default=True)
class User(Base):
    __tablename__='users'; id:Mapped[int]=mapped_column(Integer,primary_key=True); username:Mapped[str]=mapped_column(String(80),unique=True,index=True); name:Mapped[str]=mapped_column(String(120)); password_hash:Mapped[str]=mapped_column(String(300)); role:Mapped[str]=mapped_column(String(40),default='user'); active:Mapped[bool]=mapped_column(Boolean,default=True)
class Account(Base):
    __tablename__='accounts'; id:Mapped[int]=mapped_column(Integer,primary_key=True); code:Mapped[str]=mapped_column(String(50),unique=True); name:Mapped[str]=mapped_column(String(150)); account_type:Mapped[str]=mapped_column(String(50)); parent_code:Mapped[str|None]=mapped_column(String(50),nullable=True)
class JournalEntry(Base):
    __tablename__='journal_entries'; id:Mapped[int]=mapped_column(Integer,primary_key=True); date:Mapped[str]=mapped_column(String(20)); description:Mapped[str]=mapped_column(String(300)); created_by:Mapped[int]=mapped_column(ForeignKey('users.id')); created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc)); lines=relationship('JournalLine',cascade='all, delete-orphan')
class JournalLine(Base):
    __tablename__='journal_lines'; id:Mapped[int]=mapped_column(Integer,primary_key=True); entry_id:Mapped[int]=mapped_column(ForeignKey('journal_entries.id')); account_code:Mapped[str]=mapped_column(String(50)); debit:Mapped[float]=mapped_column(Float,default=0); credit:Mapped[float]=mapped_column(Float,default=0); description:Mapped[str]=mapped_column(String(300),default='')
class Customer(Base):
    __tablename__='customers'; id:Mapped[int]=mapped_column(Integer,primary_key=True); name:Mapped[str]=mapped_column(String(180)); phone:Mapped[str]=mapped_column(String(80),default=''); tax_no:Mapped[str]=mapped_column(String(100),default=''); notes:Mapped[str]=mapped_column(Text,default='')
class Shipment(Base):
    __tablename__='shipments'; id:Mapped[int]=mapped_column(Integer,primary_key=True); client_name:Mapped[str]=mapped_column(String(180)); importer_name:Mapped[str]=mapped_column(String(180),default=''); declaration_no:Mapped[str]=mapped_column(String(100),default=''); gate_no:Mapped[str]=mapped_column(String(100),default=''); bill_of_lading:Mapped[str]=mapped_column(String(120),default=''); container_no:Mapped[str]=mapped_column(String(120),default=''); port:Mapped[str]=mapped_column(String(120),default=''); status:Mapped[str]=mapped_column(String(50),default='جديدة')
class Audit(Base):
    __tablename__='audit_log'; id:Mapped[int]=mapped_column(Integer,primary_key=True); at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc)); action:Mapped[str]=mapped_column(String(50)); entity:Mapped[str]=mapped_column(String(80)); entity_id:Mapped[str]=mapped_column(String(100),default=''); user_id:Mapped[int]=mapped_column(Integer)
class CustomField(Base):
    __tablename__='custom_fields'; id:Mapped[int]=mapped_column(Integer,primary_key=True); entity:Mapped[str]=mapped_column(String(80),index=True); key:Mapped[str]=mapped_column(String(80)); label:Mapped[str]=mapped_column(String(150)); field_type:Mapped[str]=mapped_column(String(30),default='text'); required:Mapped[bool]=mapped_column(Boolean,default=False)

class Supplier(Base):
    __tablename__='suppliers'; id:Mapped[int]=mapped_column(Integer,primary_key=True); name:Mapped[str]=mapped_column(String(180)); phone:Mapped[str]=mapped_column(String(80),default=''); tax_no:Mapped[str]=mapped_column(String(100),default=''); notes:Mapped[str]=mapped_column(Text,default='')
class FiscalPeriod(Base):
    __tablename__='fiscal_periods'; id:Mapped[int]=mapped_column(Integer,primary_key=True); name:Mapped[str]=mapped_column(String(120),unique=True); start_date:Mapped[str]=mapped_column(String(20)); end_date:Mapped[str]=mapped_column(String(20)); closed:Mapped[bool]=mapped_column(Boolean,default=False)
class OpeningBalance(Base):
    __tablename__='opening_balances'; id:Mapped[int]=mapped_column(Integer,primary_key=True); account_code:Mapped[str]=mapped_column(String(50)); date:Mapped[str]=mapped_column(String(20)); debit:Mapped[float]=mapped_column(Float,default=0); credit:Mapped[float]=mapped_column(Float,default=0); note:Mapped[str]=mapped_column(String(300),default=''); posted:Mapped[bool]=mapped_column(Boolean,default=False); journal_entry_id:Mapped[int|None]=mapped_column(ForeignKey('journal_entries.id'),nullable=True)
class SchemaInfo(Base):
    __tablename__='schema_info'; id:Mapped[int]=mapped_column(Integer,primary_key=True); version:Mapped[str]=mapped_column(String(30)); updated_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc),onupdate=lambda:datetime.now(timezone.utc))
class FiscalClose(Base):
    __tablename__='fiscal_closes'; id:Mapped[int]=mapped_column(Integer,primary_key=True); period_id:Mapped[int]=mapped_column(ForeignKey('fiscal_periods.id'),unique=True); journal_entry_id:Mapped[int|None]=mapped_column(ForeignKey('journal_entries.id'),nullable=True); net_profit:Mapped[float]=mapped_column(Float,default=0); closed_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc)); closed_by:Mapped[int]=mapped_column(ForeignKey('users.id'))
class JournalReversal(Base):
    __tablename__='journal_reversals'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    original_entry_id:Mapped[int]=mapped_column(ForeignKey('journal_entries.id'),unique=True,index=True)
    reversal_entry_id:Mapped[int]=mapped_column(ForeignKey('journal_entries.id'),unique=True,index=True)
    reason:Mapped[str]=mapped_column(String(300),default='')
    created_by:Mapped[int]=mapped_column(ForeignKey('users.id'))
    created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))

class AccountMapping(Base):
    __tablename__='account_mappings'; key:Mapped[str]=mapped_column(String(80),primary_key=True); account_code:Mapped[str]=mapped_column(String(50)); description:Mapped[str]=mapped_column(String(200),default='')
class Purchase(Base):
    __tablename__='purchases'; id:Mapped[int]=mapped_column(Integer,primary_key=True); number:Mapped[str]=mapped_column(String(80),unique=True,index=True); date:Mapped[str]=mapped_column(String(20)); supplier_id:Mapped[int|None]=mapped_column(ForeignKey('suppliers.id'),nullable=True); description:Mapped[str]=mapped_column(String(300),default=''); total:Mapped[float]=mapped_column(Float,default=0); posted:Mapped[bool]=mapped_column(Boolean,default=False)
class PurchaseLine(Base):
    __tablename__='purchase_lines'; id:Mapped[int]=mapped_column(Integer,primary_key=True); purchase_id:Mapped[int]=mapped_column(ForeignKey('purchases.id')); description:Mapped[str]=mapped_column(String(300)); qty:Mapped[float]=mapped_column(Float,default=1); unit_price:Mapped[float]=mapped_column(Float,default=0); total:Mapped[float]=mapped_column(Float,default=0)
class Expense(Base):
    __tablename__='expenses'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    number:Mapped[str]=mapped_column(String(80),unique=True,index=True)
    date:Mapped[str]=mapped_column(String(20))
    expense_type:Mapped[str]=mapped_column(String(50))
    description:Mapped[str]=mapped_column(String(300),default='')
    amount:Mapped[float]=mapped_column(Float,default=0)
    expense_account_code:Mapped[str]=mapped_column(String(50))
    payment_account_code:Mapped[str]=mapped_column(String(50))
    supplier_id:Mapped[int|None]=mapped_column(ForeignKey('suppliers.id'),nullable=True)
    shipment_id:Mapped[int|None]=mapped_column(ForeignKey('shipments.id'),nullable=True)
    reference:Mapped[str]=mapped_column(String(120),default='')
    posted:Mapped[bool]=mapped_column(Boolean,default=False)

Base.metadata.create_all(engine)
def db():
    s=SessionLocal()
    try: yield s
    finally: s.close()
def hash_pw(p:str,salt=None):
    salt=salt or secrets.token_hex(16); return salt+'$'+hashlib.pbkdf2_hmac('sha256',p.encode(),salt.encode(),210000).hex()
def check_pw(p,h):
    try: salt,stored=h.split('$',1); return secrets.compare_digest(hash_pw(p,salt).split('$',1)[1],stored)
    except: return False
def token(u:User): return jwt.encode({'sub':str(u.id),'role':u.role,'iat':datetime.now(timezone.utc),'exp':datetime.now(timezone.utc)+timedelta(hours=8)},SECRET,algorithm='HS256')
def current_user(authorization:str|None=Header(default=None), s:Session=Depends(db)):
    if not authorization or not authorization.startswith('Bearer '): raise HTTPException(401,'تسجيل الدخول مطلوب')
    try: uid=int(jwt.decode(authorization[7:],SECRET,algorithms=['HS256'])['sub'])
    except: raise HTTPException(401,'جلسة غير صالحة')
    u=s.get(User,uid)
    if not u or not u.active: raise HTTPException(401,'المستخدم غير فعال')
    return u
def manager(u=Depends(current_user)):
    if u.role!='manager': raise HTTPException(403,'صلاحية المدير مطلوبة')
    return u
def audit(s,u,action,entity,eid=''): s.add(Audit(action=action,entity=entity,entity_id=str(eid),user_id=u.id)); s.commit()

app=FastAPI(title='ثابت أنعم ERP API',version=APP_VERSION)
app.add_middleware(CORSMiddleware,allow_origins=ALLOWED_ORIGINS,allow_credentials=False,allow_methods=['GET','POST','PUT','PATCH','DELETE','OPTIONS'],allow_headers=['Authorization','Content-Type'])

@app.middleware('http')
async def security_headers(request, call_next):
    response=await call_next(request)
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['X-Frame-Options']='DENY'
    response.headers['Referrer-Policy']='no-referrer'
    response.headers['Permissions-Policy']='camera=(), microphone=(), geolocation=()'
    if os.getenv('ENVIRONMENT','development').lower()=='production':
        response.headers['Strict-Transport-Security']='max-age=31536000; includeSubDomains'
    return response
@app.on_event('startup')
def seed():
    s=SessionLocal()
    if os.getenv('ENVIRONMENT','development').lower()=='production':
        if SECRET=='change-this-secret-before-production' or len(SECRET)<32:
            s.close()
            raise RuntimeError('THABET_SECRET must be a unique secret of at least 32 characters in production')
        admin=s.query(User).filter_by(username='admin').first()
        if admin and check_pw('admin123', admin.password_hash):
            s.close()
            raise RuntimeError('Default admin password must be changed before production')
    if not s.query(User).first(): s.add(User(username='admin',name='المدير',password_hash=hash_pw('admin123'),role='manager'))
    if not s.query(Setting).first():
        for k,v in {'company_name':'ثابت أنعم للتخليص الجمركي','base_currency':'YER','language':'ar'}.items(): s.add(Setting(key=k,value=v))
    if not s.query(Module).first():
        for k,n in {'accounting':'المحاسبة','customs':'التخليص الجمركي','customers':'العملاء','inventory':'المخزون','documents':'المستندات','ai':'الذكاء الاصطناعي','reports':'التقارير'}.items(): s.add(Module(key=k,name=n))
    if not s.query(Account).first():
        seed_accounts=[('1000','الأصول','asset',None),('1100','العملاء','asset','1000'),('1110','الصندوق','asset','1000'),('1120','البنك','asset','1000'),('1200','المخزون','asset','1000'),('2000','الالتزامات','liability',None),('2100','الموردون','liability','2000'),('3000','حقوق الملكية','equity',None),('4000','الإيرادات','income',None),('4100','إيرادات خدمات التخليص','income','4000'),('5000','المصروفات','expense',None),('5100','مصروفات تشغيلية','expense','5000'),('5200','مصروفات إدارية','expense','5000')]
        for code,name,typ,parent in seed_accounts: s.add(Account(code=code,name=name,account_type=typ,parent_code=parent))
    defaults={'customer_receivable':'1100','cash':'1110','bank':'1120','inventory':'1200','supplier_payable':'2100','customs_revenue':'4100','operating_expense':'5100','admin_expense':'5200','facilitation_expense':'5100'}
    for k,code in defaults.items():
        if not s.get(AccountMapping,k): s.add(AccountMapping(key=k,account_code=code,description='خريطة حساب افتراضية'))
    if not s.query(FiscalPeriod).first():
        s.add(FiscalPeriod(name='2026',start_date='2026-01-01',end_date='2026-12-31',closed=False))
    
    if not s.query(Permission).first():
        for role in ['user']:
            for module in ['accounting','customs','customers','suppliers','reports']:
                for action in ['view','create','post']:
                    s.add(Permission(role=role,module=module,action=action,allowed=True))
        s.add(Permission(role='user',module='admin',action='view',allowed=False))
    si=s.query(SchemaInfo).first()
    if not si: s.add(SchemaInfo(version=APP_VERSION))
    else: si.version=APP_VERSION
    s.commit(); s.close()

class Login(BaseModel): username:str; password:str
class SettingIn(BaseModel): value:Any
class ModuleIn(BaseModel): enabled:bool
class UserIn(BaseModel): username:str; name:str; password:str=Field(min_length=6); role:str='user'; active:bool=True
class AccountIn(BaseModel): code:str; name:str; account_type:str; parent_code:str|None=None
class LineIn(BaseModel): account_code:str; debit:float=0; credit:float=0; description:str=''
class JournalIn(BaseModel): date:str; description:str; lines:list[LineIn]
class ReverseJournalIn(BaseModel): reason:str=Field(min_length=3, max_length=300)

class UserPatch(BaseModel): name:str|None=None; role:str|None=None; active:bool|None=None; password:str|None=None
class CustomerIn(BaseModel): name:str; phone:str=''; tax_no:str=''; notes:str=''
class ShipmentIn(BaseModel): client_name:str; importer_name:str=''; declaration_no:str=''; gate_no:str=''; bill_of_lading:str=''; container_no:str=''; port:str=''; status:str='جديدة'
class FieldIn(BaseModel): entity:str; key:str; label:str; field_type:str='text'; required:bool=False

@app.get('/api/system/schema')
def schema_health(s=Depends(db),u=Depends(manager)):
    si=s.query(SchemaInfo).first()
    return {'application_version':APP_VERSION,'schema_version':si.version if si else None,'status':'ok' if si and si.version==APP_VERSION else 'migration_required'}

@app.get('/api/accounting/controls')
def accounting_controls(s=Depends(db),u=Depends(current_user)):
    entries=s.query(JournalEntry).all()
    unbalanced=[]
    for e in entries:
        d=round(sum(l.debit for l in e.lines),2); c=round(sum(l.credit for l in e.lines),2)
        if d!=c or d<=0: unbalanced.append({'id':e.id,'date':e.date,'debit':d,'credit':c})
    return {'journal_entries':len(entries),'unbalanced_entries':unbalanced[:100], 'unbalanced_count':len(unbalanced), 'open_periods':s.query(FiscalPeriod).filter_by(closed=False).count(), 'status':'ok' if not unbalanced else 'attention'}

@app.get('/api/accounting/integrity')
def accounting_integrity(s=Depends(db),u=Depends(current_user)):
    issues=[]
    for e in s.query(JournalEntry).all():
        debit=round(sum(float(l.debit or 0) for l in e.lines),2)
        credit=round(sum(float(l.credit or 0) for l in e.lines),2)
        if debit<=0 or abs(debit-credit)>0.005:
            issues.append({'type':'unbalanced_journal','id':e.id,'debit':debit,'credit':credit})
    for inv in s.query(Invoice).filter(Invoice.posted==True).all():
        paid=round(sum(float(v.amount or 0) for v in s.query(Voucher).filter(Voucher.invoice_id==inv.id,Voucher.voucher_type=='قبض',Voucher.posted==True).all()),2)
        if paid>round(inv.total,2)+0.005:
            issues.append({'type':'invoice_overpaid','id':inv.id,'total':round(inv.total,2),'paid':paid})
    return {'status':'ok' if not issues else 'attention','issue_count':len(issues),'issues':issues[:200]}

@app.get('/api/reports/customer-financial-summary-v3')
def customer_financial_summary_v3(s=Depends(db),u=Depends(current_user)):
    out=[]
    for c in s.query(Customer).order_by(Customer.name).all():
        invs=s.query(Invoice).filter(Invoice.customer_id==c.id,Invoice.posted==True).all()
        receipts=s.query(Voucher).filter(Voucher.invoice_id.isnot(None),Voucher.voucher_type=='قبض',Voucher.posted==True).all()
        receipts=[v for v in receipts if s.get(Invoice,v.invoice_id) and s.get(Invoice,v.invoice_id).customer_id==c.id]
        total=round(sum(i.total for i in invs),2); paid=round(sum(v.amount for v in receipts),2); balance=round(total-paid,2)
        out.append({'customer_id':c.id,'customer_name':c.name,'total_invoices':total,'total_paid':paid,'outstanding':balance,'invoice_count':len(invs),'receipt_count':len(receipts),'status':'مسدد' if balance<=0.005 else 'عليه رصيد'})
    return out

@app.get('/')
def root(): return {'system':'ثابت أنعم ERP','version':APP_VERSION,'status':'running'}
@app.get('/api/system/health')
def system_health():
    return {'status':'ok','system':'ثابت أنعم ERP','version':APP_VERSION}

@app.get('/api/admin/integrity/full')
def full_integrity_check(s=Depends(db),u=Depends(manager)):
    findings=system_integrity_scan(s)
    return {'version':APP_VERSION,'status':'ok' if not findings else 'attention_required','critical':sum(1 for x in findings if x['severity']=='critical'),'warnings':sum(1 for x in findings if x['severity']=='warning'),'findings':findings}

@app.get('/api/system/info')
def system_info(s:Session=Depends(db),u=Depends(current_user)):
    return {
        'system':'ثابت أنعم ERP', 'version':APP_VERSION, 'status':'running',
        'database':'postgresql' if 'postgresql' in str(engine.url) else 'sqlite',
        'backup_ready': True,
        'security': {'jwt_hours': 8, 'audit_log': True, 'production_secret_required': True},
        'mobile_ready': True, 'deployment':'docker', 'integrity_check':True
    }

@app.post('/api/auth/login')
def login(x:Login, request:Request, s:Session=Depends(db)):
    ip=request.client.host if request.client else 'unknown'
    _check_login_rate(ip,x.username)
    u=s.query(User).filter_by(username=x.username).first()
    if not u or not u.active or not check_pw(x.password,u.password_hash):
        _record_login_failure(ip,x.username)
        raise HTTPException(401,'اسم المستخدم أو كلمة المرور غير صحيحة')
    _clear_login_failures(ip,x.username)
    if u.role not in {'manager','user'}: raise HTTPException(403,'دور المستخدم غير صالح')
    audit(s,u,'login','user',u.id)
    return {'access_token':token(u),'expires_in':28800,'user':{'id':u.id,'username':u.username,'name':u.name,'role':u.role}}
@app.get('/api/me')
def me(u=Depends(current_user)): return {'id':u.id,'username':u.username,'name':u.name,'role':u.role}
@app.get('/api/dashboard')
def dashboard(s:Session=Depends(db),u=Depends(current_user)):
    return {'users':s.query(User).filter_by(active=True).count(),'accounts':s.query(Account).count(),'journal_entries':s.query(JournalEntry).count(),'shipments':s.query(Shipment).count(),'customers':s.query(Customer).count(),'modules_enabled':s.query(Module).filter_by(enabled=True).count(),'suppliers':s.query(Supplier).count(),'purchases':s.query(Purchase).count(),'expenses':s.query(Expense).count()}
@app.get('/api/admin/settings')
def settings(s=Depends(db),u=Depends(current_user)): return {x.key:x.value for x in s.query(Setting).all()}
@app.put('/api/admin/settings/{key}')
def set_setting(key:str,x:SettingIn,s=Depends(db),u=Depends(manager)):
    z=s.get(Setting,key) or Setting(key=key); z.value=str(x.value); s.add(z); s.commit(); audit(s,u,'update','setting',key); return {'key':key,'value':z.value}
@app.get('/api/admin/modules')
def modules(s=Depends(db),u=Depends(current_user)): return {x.key:{'name':x.name,'enabled':x.enabled} for x in s.query(Module).all()}
@app.put('/api/admin/modules/{key}')
def set_module(key:str,x:ModuleIn,s=Depends(db),u=Depends(manager)):
    z=s.get(Module,key)
    if not z: raise HTTPException(404,'الوحدة غير موجودة')
    z.enabled=x.enabled; s.commit(); audit(s,u,'update','module',key); return {'key':key,'enabled':z.enabled}
@app.get('/api/users')
def users(s=Depends(db),u=Depends(manager)): return [{'id':x.id,'username':x.username,'name':x.name,'role':x.role,'active':x.active} for x in s.query(User).all()]
@app.post('/api/users')
def add_user(x:UserIn,s=Depends(db),u=Depends(manager)):
    if s.query(User).filter_by(username=x.username).first(): raise HTTPException(409,'اسم المستخدم موجود')
    z=User(username=x.username,name=x.name,password_hash=hash_pw(x.password),role=x.role,active=x.active); s.add(z); s.commit(); audit(s,u,'create','user',z.id); return {'id':z.id,'username':z.username,'name':z.name,'role':z.role,'active':z.active}
@app.patch('/api/users/{user_id}')
def patch_user(user_id:int,x:UserPatch,s=Depends(db),u=Depends(manager)):
    z=s.get(User,user_id)
    if not z: raise HTTPException(404,'المستخدم غير موجود')
    if z.id==u.id and x.active is False: raise HTTPException(400,'لا يمكن للمدير تعطيل حسابه الحالي')
    if x.role is not None and x.role not in {'manager','user'}: raise HTTPException(400,'الدور غير صالح')
    if x.role=='user' and z.role=='manager' and s.query(User).filter_by(role='manager',active=True).count()<=1: raise HTTPException(400,'يجب إبقاء مدير فعال واحد على الأقل')
    if x.name is not None: z.name=x.name
    if x.role is not None: z.role=x.role
    if x.active is not None: z.active=x.active
    if x.password is not None: z.password_hash=hash_pw(x.password)
    s.commit(); audit(s,u,'update','user',z.id)
    return {'id':z.id,'username':z.username,'name':z.name,'role':z.role,'active':z.active}
@app.get('/api/accounts')
def accounts(s=Depends(db),u=Depends(current_user)): return [{'id':x.id,'code':x.code,'name':x.name,'account_type':x.account_type,'parent_code':x.parent_code} for x in s.query(Account).order_by(Account.code).all()]
@app.post('/api/accounts')
def add_account(x:AccountIn,s=Depends(db),u=Depends(current_user)):
    if s.query(Account).filter_by(code=x.code).first(): raise HTTPException(409,'رقم الحساب موجود')
    z=Account(**x.model_dump()); s.add(z); s.commit(); audit(s,u,'create','account',z.id); return {'id':z.id,**x.model_dump()}
@app.get('/api/journal')
def journal(s=Depends(db),u=Depends(current_user)):
    out=[]
    for e in s.query(JournalEntry).order_by(JournalEntry.id.desc()).all(): out.append({'id':e.id,'date':e.date,'description':e.description,'lines':[{'account_code':l.account_code,'debit':l.debit,'credit':l.credit,'description':l.description} for l in e.lines]})
    return out
@app.post('/api/journal')
def add_journal(x:JournalIn,s=Depends(db),u=Depends(current_user)):
    if not has_permission(s,u,'accounting','post'): raise HTTPException(403,'لا تملك صلاحية ترحيل القيود')
    lines=[(l.account_code,l.debit,l.credit,l.description) for l in x.lines]
    z=post_journal(s,u,x.date,x.description,lines)
    s.commit(); audit(s,u,'post','journal_entry',z.id); return {'id':z.id,'status':'posted'}
@app.post('/api/journal/{entry_id}/reverse-v3')
def reverse_journal_v3(entry_id:int,x:ReverseJournalIn,s=Depends(db),u=Depends(current_user)):
    if not has_permission(s,u,'accounting','post'): raise HTTPException(403,'لا تملك صلاحية عكس القيود')
    original=s.get(JournalEntry,entry_id)
    if not original: raise HTTPException(404,'القيد غير موجود')
    if s.query(JournalReversal).filter_by(original_entry_id=entry_id).first(): raise HTTPException(409,'تم عكس القيد مسبقًا')
    reverse_date=datetime.now().strftime('%Y-%m-%d'); ensure_open_period(s,reverse_date)
    lines=[(l.account_code,l.credit,l.debit,'عكس: '+(l.description or original.description)) for l in original.lines]
    try:
        rev=post_journal(s,u,reverse_date,'عكس القيد #'+str(entry_id)+' - '+x.reason,lines)
        s.add(JournalReversal(original_entry_id=entry_id,reversal_entry_id=rev.id,reason=x.reason,created_by=u.id))
        s.commit(); audit(s,u,'reverse','journal_entry',entry_id)
        return {'original_entry_id':entry_id,'reversal_entry_id':rev.id,'status':'reversed'}
    except Exception:
        s.rollback(); raise

@app.get('/api/accounting/ledger/{account_code}')
def account_ledger(account_code:str,date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    """General ledger for one account, using posted journal entries only."""
    acc=s.query(Account).filter(Account.code==account_code).first()
    if not acc: raise HTTPException(404,'الحساب غير موجود')
    if date_from and date_to and date_from>date_to: raise HTTPException(400,'تاريخ البداية أكبر من النهاية')
    q=s.query(JournalEntry).join(JournalLine,JournalLine.entry_id==JournalEntry.id).filter(JournalLine.account_code==account_code)
    if date_from: q=q.filter(JournalEntry.date>=date_from)
    if date_to: q=q.filter(JournalEntry.date<=date_to)
    entries=q.order_by(JournalEntry.date,JournalEntry.id).distinct().all()
    rows=[]; debit=credit=balance=0.0
    for e in entries:
        for l in sorted([x for x in e.lines if x.account_code==account_code], key=lambda x:x.id):
            d=round(float(l.debit or 0),2); c=round(float(l.credit or 0),2)
            debit=round(debit+d,2); credit=round(credit+c,2); balance=round(balance+d-c,2)
            rows.append({'date':e.date,'entry_id':e.id,'description':e.description,'line_description':l.description,
                         'debit':d,'credit':c,'balance':balance})
    return {'account':{'code':acc.code,'name':acc.name,'account_type':acc.account_type},
            'filters':{'date_from':date_from,'date_to':date_to},'rows':rows,
            'summary':{'debit':debit,'credit':credit,'balance':balance,'movement_count':len(rows)}}

@app.get('/api/customers')
def customers(s=Depends(db),u=Depends(current_user)): return [x.__dict__|{} for x in s.query(Customer).all()]
@app.post('/api/customers')
def add_customer(x:CustomerIn,s=Depends(db),u=Depends(current_user)):
    z=Customer(**x.model_dump()); s.add(z); s.commit(); audit(s,u,'create','customer',z.id); return {'id':z.id,**x.model_dump()}
@app.get('/api/shipments')
def shipments(s=Depends(db),u=Depends(current_user)): return [x.__dict__|{} for x in s.query(Shipment).order_by(Shipment.id.desc()).all()]
@app.post('/api/shipments')
def add_shipment(x:ShipmentIn,s=Depends(db),u=Depends(current_user)):
    z=Shipment(**x.model_dump()); s.add(z); s.commit(); audit(s,u,'create','shipment',z.id); return {'id':z.id,**x.model_dump()}
@app.get('/api/admin/custom-fields')
def fields(entity:str|None=None,s=Depends(db),u=Depends(current_user)):
    q=s.query(CustomField); q=q.filter_by(entity=entity) if entity else q; return [{'id':x.id,'entity':x.entity,'key':x.key,'label':x.label,'field_type':x.field_type,'required':x.required} for x in q.all()]
@app.post('/api/admin/custom-fields')
def add_field(x:FieldIn,s=Depends(db),u=Depends(manager)):
    z=CustomField(**x.model_dump()); s.add(z); s.commit(); audit(s,u,'create','custom_field',z.id); return {'id':z.id,**x.model_dump()}
@app.get('/api/audit')
def audits(action:str|None=None,entity:str|None=None,user_id:int|None=None,date_from:str|None=None,date_to:str|None=None,limit:int=300,s=Depends(db),u=Depends(manager)):
    q=s.query(Audit)
    if action: q=q.filter(Audit.action==action)
    if entity: q=q.filter(Audit.entity==entity)
    if user_id: q=q.filter(Audit.user_id==user_id)
    if date_from: q=q.filter(Audit.at>=date_from)
    if date_to: q=q.filter(Audit.at<=date_to+'T23:59:59')
    limit=max(1,min(limit,1000))
    return [{'id':x.id,'at':x.at.isoformat(),'action':x.action,'entity':x.entity,'entity_id':x.entity_id,'user_id':x.user_id} for x in q.order_by(Audit.id.desc()).limit(limit).all()]

# ===== V0.3 business modules =====
class Invoice(Base):
    __tablename__='invoices'; id:Mapped[int]=mapped_column(Integer,primary_key=True); number:Mapped[str]=mapped_column(String(80),unique=True,index=True); date:Mapped[str]=mapped_column(String(20)); customer_id:Mapped[int|None]=mapped_column(ForeignKey('customers.id'),nullable=True); description:Mapped[str]=mapped_column(String(300),default=''); total:Mapped[float]=mapped_column(Float,default=0); paid:Mapped[float]=mapped_column(Float,default=0); status:Mapped[str]=mapped_column(String(40),default='غير مسددة'); posted:Mapped[bool]=mapped_column(Boolean,default=False)
class InvoiceLine(Base):
    __tablename__='invoice_lines'; id:Mapped[int]=mapped_column(Integer,primary_key=True); invoice_id:Mapped[int]=mapped_column(ForeignKey('invoices.id')); description:Mapped[str]=mapped_column(String(300)); qty:Mapped[float]=mapped_column(Float,default=1); unit_price:Mapped[float]=mapped_column(Float,default=0); total:Mapped[float]=mapped_column(Float,default=0)
class Voucher(Base):
    __tablename__='vouchers'; id:Mapped[int]=mapped_column(Integer,primary_key=True); number:Mapped[str]=mapped_column(String(80),unique=True,index=True); date:Mapped[str]=mapped_column(String(20)); voucher_type:Mapped[str]=mapped_column(String(30)); cash_box:Mapped[str]=mapped_column(String(100),default=''); reference:Mapped[str]=mapped_column(String(120),default=''); description:Mapped[str]=mapped_column(String(300),default=''); amount:Mapped[float]=mapped_column(Float,default=0); account_code:Mapped[str]=mapped_column(String(50),default=''); invoice_id:Mapped[int|None]=mapped_column(ForeignKey('invoices.id'),nullable=True); posted:Mapped[bool]=mapped_column(Boolean,default=False)
class ShipmentItem(Base):
    __tablename__='shipment_items'; id:Mapped[int]=mapped_column(Integer,primary_key=True); shipment_id:Mapped[int]=mapped_column(ForeignKey('shipments.id')); description:Mapped[str]=mapped_column(String(300)); barcode:Mapped[str]=mapped_column(String(100),default=''); qty:Mapped[float]=mapped_column(Float,default=0); cartons:Mapped[float]=mapped_column(Float,default=0); net_weight:Mapped[float]=mapped_column(Float,default=0); unit_price:Mapped[float]=mapped_column(Float,default=0); customs_value:Mapped[float]=mapped_column(Float,default=0)
class Document(Base):
    __tablename__='documents'; id:Mapped[int]=mapped_column(Integer,primary_key=True); shipment_id:Mapped[int|None]=mapped_column(ForeignKey('shipments.id'),nullable=True); doc_type:Mapped[str]=mapped_column(String(80)); file_name:Mapped[str]=mapped_column(String(250)); notes:Mapped[str]=mapped_column(Text,default=''); uploaded_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))
class ShipmentProfile(Base):
    __tablename__='shipment_profiles'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    shipment_id:Mapped[int]=mapped_column(ForeignKey('shipments.id'),unique=True,index=True)
    shipment_date:Mapped[str]=mapped_column(String(20),default='')
    importer_name:Mapped[str]=mapped_column(String(180),default='')
    trade_name:Mapped[str]=mapped_column(String(180),default='')
    tax_no:Mapped[str]=mapped_column(String(100),default='')
    declaration_date:Mapped[str]=mapped_column(String(20),default='')
    transport_means:Mapped[str]=mapped_column(String(180),default='')
    goods_type:Mapped[str]=mapped_column(String(180),default='')
    origin_country:Mapped[str]=mapped_column(String(120),default='')
    currency:Mapped[str]=mapped_column(String(20),default='USD')
    exchange_rate:Mapped[float]=mapped_column(Float,default=1)
    invoice_no:Mapped[str]=mapped_column(String(120),default='')
    packing_list_no:Mapped[str]=mapped_column(String(120),default='')
    certificate_no:Mapped[str]=mapped_column(String(120),default='')

class ShipmentChecklist(Base):
    __tablename__='shipment_checklist'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    shipment_id:Mapped[int]=mapped_column(ForeignKey('shipments.id'),index=True)
    doc_type:Mapped[str]=mapped_column(String(80))
    required:Mapped[bool]=mapped_column(Boolean,default=True)
    received:Mapped[bool]=mapped_column(Boolean,default=False)
    notes:Mapped[str]=mapped_column(Text,default='')

class MatchRun(Base):
    __tablename__='match_runs'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    shipment_id:Mapped[int]=mapped_column(ForeignKey('shipments.id'),index=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))
    created_by:Mapped[int]=mapped_column(Integer)
    score:Mapped[float]=mapped_column(Float,default=0)
    status:Mapped[str]=mapped_column(String(40),default='مراجعة')
    summary:Mapped[str]=mapped_column(Text,default='')

class DocumentFile(Base):
    __tablename__='document_files'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    document_id:Mapped[int]=mapped_column(ForeignKey('documents.id'),index=True)
    stored_name:Mapped[str]=mapped_column(String(300))
    original_name:Mapped[str]=mapped_column(String(300))
    mime_type:Mapped[str]=mapped_column(String(150),default='application/octet-stream')
    size_bytes:Mapped[int]=mapped_column(Integer,default=0)
    sha256:Mapped[str]=mapped_column(String(64),index=True)
    uploaded_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))

class DocumentItem(Base):
    __tablename__='document_items'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    shipment_id:Mapped[int]=mapped_column(ForeignKey('shipments.id'),index=True)
    source:Mapped[str]=mapped_column(String(50),index=True)
    line_no:Mapped[int]=mapped_column(Integer,default=0)
    description:Mapped[str]=mapped_column(String(300),default='')
    barcode:Mapped[str]=mapped_column(String(100),default='')
    qty:Mapped[float]=mapped_column(Float,default=0)
    cartons:Mapped[float]=mapped_column(Float,default=0)
    net_weight:Mapped[float]=mapped_column(Float,default=0)
    unit_price:Mapped[float]=mapped_column(Float,default=0)
    customs_value:Mapped[float]=mapped_column(Float,default=0)
    currency:Mapped[str]=mapped_column(String(20),default='USD')

class MatchResult(Base):
    __tablename__='match_results'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    run_id:Mapped[int]=mapped_column(ForeignKey('match_runs.id'),index=True)
    item_key:Mapped[str]=mapped_column(String(180),default='')
    source_a:Mapped[str]=mapped_column(String(40),default='')
    source_b:Mapped[str]=mapped_column(String(40),default='')
    description:Mapped[str]=mapped_column(String(300),default='')
    status:Mapped[str]=mapped_column(String(40),default='')
    differences:Mapped[str]=mapped_column(Text,default='')

class CustomFieldValue(Base):
    __tablename__='custom_field_values'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    entity:Mapped[str]=mapped_column(String(80),index=True)
    entity_id:Mapped[int]=mapped_column(Integer,index=True)
    field_key:Mapped[str]=mapped_column(String(80),index=True)
    value:Mapped[str]=mapped_column(Text,default='')

class WorkflowDefinition(Base):
    __tablename__='workflow_definitions'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    entity:Mapped[str]=mapped_column(String(80),index=True)
    name:Mapped[str]=mapped_column(String(150))
    states_json:Mapped[str]=mapped_column(Text,default='[]')
    active:Mapped[bool]=mapped_column(Boolean,default=True)

class WorkflowRecord(Base):
    __tablename__='workflow_records'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    workflow_id:Mapped[int]=mapped_column(ForeignKey('workflow_definitions.id'),index=True)
    entity_id:Mapped[int]=mapped_column(Integer,index=True)
    state:Mapped[str]=mapped_column(String(100),default='جديدة')
    updated_by:Mapped[int]=mapped_column(Integer)
    updated_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))

class Permission(Base):
    __tablename__='permissions'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    role:Mapped[str]=mapped_column(String(40),index=True)
    module:Mapped[str]=mapped_column(String(80),index=True)
    action:Mapped[str]=mapped_column(String(80),index=True)
    allowed:Mapped[bool]=mapped_column(Boolean,default=False)

class ReportDefinition(Base):
    __tablename__='report_definitions'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    name:Mapped[str]=mapped_column(String(150),unique=True)
    source:Mapped[str]=mapped_column(String(50))
    columns_json:Mapped[str]=mapped_column(Text,default='[]')
    active:Mapped[bool]=mapped_column(Boolean,default=True)

class CustomerImporter(Base):
    __tablename__='customer_importers'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    customer_id:Mapped[int]=mapped_column(ForeignKey('customers.id'),index=True)
    importer_name:Mapped[str]=mapped_column(String(180))
    trade_name:Mapped[str]=mapped_column(String(180),default='')
    authorization_from:Mapped[str]=mapped_column(String(20),default='')
    authorization_to:Mapped[str]=mapped_column(String(20),default='')
    tax_no:Mapped[str]=mapped_column(String(100),default='')
    commercial_register:Mapped[str]=mapped_column(String(100),default='')
    activity:Mapped[str]=mapped_column(String(200),default='')
    notes:Mapped[str]=mapped_column(Text,default='')

class Service(Base):
    __tablename__='services'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    code:Mapped[str]=mapped_column(String(60),unique=True,index=True)
    name:Mapped[str]=mapped_column(String(180))
    service_type:Mapped[str]=mapped_column(String(60),default='تخليص')
    default_price:Mapped[float]=mapped_column(Float,default=0)
    active:Mapped[bool]=mapped_column(Boolean,default=True)
    notes:Mapped[str]=mapped_column(Text,default='')

class CustomerService(Base):
    __tablename__='customer_services'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    customer_id:Mapped[int]=mapped_column(ForeignKey('customers.id'),index=True)
    service_id:Mapped[int]=mapped_column(ForeignKey('services.id'),index=True)
    date:Mapped[str]=mapped_column(String(20))
    quantity:Mapped[float]=mapped_column(Float,default=1)
    unit_price:Mapped[float]=mapped_column(Float,default=0)
    description:Mapped[str]=mapped_column(String(300),default='')
    invoice_id:Mapped[int|None]=mapped_column(ForeignKey('invoices.id'),nullable=True,index=True)
    status:Mapped[str]=mapped_column(String(40),default='مفتوحة')

class Claim(Base):
    __tablename__='claims'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    customer_id:Mapped[int]=mapped_column(ForeignKey('customers.id'),index=True)
    shipment_id:Mapped[int|None]=mapped_column(ForeignKey('shipments.id'),nullable=True,index=True)
    claim_no:Mapped[str]=mapped_column(String(80),unique=True,index=True)
    date:Mapped[str]=mapped_column(String(20))
    subject:Mapped[str]=mapped_column(String(250))
    amount:Mapped[float]=mapped_column(Float,default=0)
    status:Mapped[str]=mapped_column(String(40),default='مفتوحة')
    notes:Mapped[str]=mapped_column(Text,default='')
    created_by:Mapped[int]=mapped_column(Integer)

Base.metadata.create_all(engine)

class CustomerImporterIn(BaseModel):
    importer_name:str; trade_name:str=''; authorization_from:str=''; authorization_to:str=''; tax_no:str=''; commercial_register:str=''; activity:str=''; notes:str=''
class ServiceIn(BaseModel):
    code:str; name:str; service_type:str='تخليص'; default_price:float=0; active:bool=True; notes:str=''
class CustomerServiceIn(BaseModel):
    service_id:int; date:str; quantity:float=1; unit_price:float=0; description:str=''; invoice_id:int|None=None; status:str='مفتوحة'
class ClaimIn(BaseModel):
    claim_no:str; date:str; subject:str; amount:float=0; shipment_id:int|None=None; status:str='مفتوحة'; notes:str=''

class CustomValueIn(BaseModel): entity:str; entity_id:int; field_key:str; value:Any
class WorkflowIn(BaseModel): entity:str; name:str; states:list[str]
class TransitionIn(BaseModel): workflow_id:int; entity_id:int; state:str
class PermissionIn(BaseModel): role:str; module:str; action:str; allowed:bool=True
class PermissionBulkIn(BaseModel): role:str; permissions:list[PermissionIn]
class ReportIn(BaseModel): name:str; source:str; columns:list[str]

class InvoiceLineIn(BaseModel): description:str; qty:float=1; unit_price:float=0
class InvoiceIn(BaseModel): number:str; date:str; customer_id:int|None=None; description:str=''; lines:list[InvoiceLineIn]
class VoucherIn(BaseModel): number:str; date:str; voucher_type:str; cash_box:str=''; reference:str=''; description:str=''; amount:float; account_code:str=''; invoice_id:int|None=None

class PasswordChange(BaseModel): old_password:str; new_password:str=Field(min_length=6)
class ShipmentItemIn(BaseModel): description:str; barcode:str=''; qty:float=0; cartons:float=0; net_weight:float=0; unit_price:float=0; customs_value:float=0
class DocumentIn(BaseModel): shipment_id:int|None=None; doc_type:str; file_name:str; notes:str=''
class SupplierIn(BaseModel): name:str; phone:str=''; tax_no:str=''; notes:str=''
class PeriodIn(BaseModel): name:str; start_date:str; end_date:str; closed:bool=False
class OpeningBalanceIn(BaseModel): account_code:str; date:str; debit:float=0; credit:float=0; note:str=''
class MappingIn(BaseModel): account_code:str; description:str=''
class PurchaseLineIn(BaseModel): description:str; qty:float=1; unit_price:float=0
class PurchaseIn(BaseModel): number:str; date:str; supplier_id:int|None=None; description:str=''; lines:list[PurchaseLineIn]
class ExpenseIn(BaseModel):
    number:str
    date:str
    expense_type:str
    description:str=''
    amount:float
    expense_account_code:str=''
    payment_account_code:str=''
    supplier_id:int|None=None
    shipment_id:int|None=None
    reference:str=''
class ShipmentProfileIn(BaseModel):
    shipment_date:str=''; importer_name:str=''; trade_name:str=''; tax_no:str=''; declaration_date:str=''; transport_means:str=''; goods_type:str=''; origin_country:str=''; currency:str='USD'; exchange_rate:float=1; invoice_no:str=''; packing_list_no:str=''; certificate_no:str=''
class ChecklistIn(BaseModel): doc_type:str; required:bool=True; received:bool=False; notes:str=''
class MatchItemIn(BaseModel): source:str; key:str=''; description:str=''; barcode:str=''; qty:float=0; cartons:float=0; net_weight:float=0; unit_price:float=0; customs_value:float=0
class MatchRequest(BaseModel): items:list[MatchItemIn]

class DocumentItemIn(BaseModel):
    source:str; line_no:int=0; description:str=''; barcode:str=''; qty:float=0; cartons:float=0; net_weight:float=0; unit_price:float=0; customs_value:float=0; currency:str='USD'
class MatchStoredRequest(BaseModel): sources:list[str]=[]


@app.get('/api/invoices')
def invoices(s=Depends(db),u=Depends(current_user)):
    return [{'id':x.id,'number':x.number,'date':x.date,'customer_id':x.customer_id,'description':x.description,'total':x.total,'paid':x.paid,'status':x.status,'posted':x.posted} for x in s.query(Invoice).order_by(Invoice.id.desc()).all()]
def post_journal(s,u,date,description,lines):
    validate_journal_lines(s, lines)
    ensure_open_period(s,date)
    z=JournalEntry(date=date,description=description,created_by=u.id); s.add(z); s.flush()
    for code,d,c,desc in lines: s.add(JournalLine(entry_id=z.id,account_code=code,debit=round(float(d),2),credit=round(float(c),2),description=desc))
    return z

def mapped_code(s,key,fallback):
    m=s.get(AccountMapping,key)
    return m.account_code if m else fallback

def ensure_open_period(s,date):
    p=s.query(FiscalPeriod).filter(FiscalPeriod.start_date<=date,FiscalPeriod.end_date>=date).first()
    if not p: raise HTTPException(400,'لا توجد فترة محاسبية تغطي تاريخ العملية')
    if p.closed: raise HTTPException(400,'الفترة المحاسبية مغلقة')
    return p

def validate_iso_date_range(date_from, date_to):
    if date_from and date_to and date_from > date_to:
        raise HTTPException(400,'تاريخ البداية يجب أن يسبق أو يساوي تاريخ النهاية')

def system_integrity_scan(s):
    findings=[]
    # Journals: every entry must remain balanced and every line must point to an account.
    for e in s.query(JournalEntry).all():
        debit=round(sum(x.debit for x in e.lines),2); credit=round(sum(x.credit for x in e.lines),2)
        if debit != credit or debit <= 0:
            findings.append({'severity':'critical','type':'unbalanced_journal','id':e.id,'detail':f'{debit}!={credit}'})
        for l in e.lines:
            if not s.query(Account).filter_by(code=l.account_code).first():
                findings.append({'severity':'critical','type':'missing_account','id':e.id,'detail':l.account_code})
    # Foreign-key style checks that SQLite does not always enforce.
    for l in s.query(JournalLine).all():
        if not s.get(JournalEntry,l.entry_id):
            findings.append({'severity':'critical','type':'orphan_journal_line','id':l.id,'detail':str(l.entry_id)})
    for p in s.query(Purchase).all():
        lines=s.query(PurchaseLine).filter_by(purchase_id=p.id).all()
        total=round(sum(x.total for x in lines),2)
        if abs(total-round(p.total,2))>0.005:
            findings.append({'severity':'warning','type':'purchase_total_mismatch','id':p.id,'detail':f'{p.total}!={total}'})
    for i in s.query(Invoice).all():
        paid=round(sum(v.amount for v in s.query(Voucher).filter(Voucher.invoice_id==i.id,Voucher.voucher_type=='قبض',Voucher.posted==True).all()),2)
        if paid-round(i.total,2)>0.005:
            findings.append({'severity':'critical','type':'invoice_overpaid','id':i.id,'detail':f'{paid}>{i.total}'})
    periods=s.query(FiscalPeriod).order_by(FiscalPeriod.start_date,FiscalPeriod.id).all()
    for idx,a in enumerate(periods):
        for b in periods[idx+1:]:
            if a.start_date<=b.end_date and b.start_date<=a.end_date:
                findings.append({'severity':'critical','type':'overlapping_fiscal_periods','id':a.id,'detail':f'{a.name} overlaps {b.name}'})
    return findings

def validate_journal_lines(s, lines):
    if not lines or len(lines) < 2: raise HTTPException(400,'القيد يجب أن يحتوي على سطرين على الأقل')
    debit=round(sum(float(a[1]) for a in lines),2); credit=round(sum(float(a[2]) for a in lines),2)
    if debit<=0 or debit!=credit: raise HTTPException(400,f'القيد غير متوازن: مدين={debit} دائن={credit}')
    for code,d,c,_ in lines:
        if float(d)<0 or float(c)<0: raise HTTPException(400,'لا يسمح بقيم سالبة في القيد')
        if float(d)>0 and float(c)>0: raise HTTPException(400,'لا يمكن أن يكون السطر مدينًا ودائنًا في الوقت نفسه')
        if not s.query(Account).filter_by(code=code).first(): raise HTTPException(400,f'الحساب غير موجود: {code}')
    return debit

@app.post('/api/invoices')
def add_invoice(x:InvoiceIn,s=Depends(db),u=Depends(current_user)):
    if s.query(Invoice).filter_by(number=x.number).first(): raise HTTPException(409,'رقم الفاتورة موجود')
    if not x.lines: raise HTTPException(400,'الفاتورة يجب أن تحتوي على بند واحد على الأقل')
    total=round(sum(l.qty*l.unit_price for l in x.lines),2)
    z=Invoice(number=x.number,date=x.date,customer_id=x.customer_id,description=x.description,total=total); s.add(z); s.flush()
    for l in x.lines: s.add(InvoiceLine(invoice_id=z.id,description=l.description,qty=l.qty,unit_price=l.unit_price,total=round(l.qty*l.unit_price,2)))
    s.commit(); audit(s,u,'create','invoice',z.id); return {'id':z.id,'number':z.number,'total':total,'posted':False}

@app.post('/api/invoices/{invoice_id}/post')
def post_invoice(invoice_id:int,s=Depends(db),u=Depends(current_user)):
    if not has_permission(s,u,'accounting','post'): raise HTTPException(403,'لا تملك صلاحية ترحيل الفواتير')
    x=s.get(Invoice,invoice_id)
    if not x: raise HTTPException(404,'الفاتورة غير موجودة')
    if x.posted: raise HTTPException(409,'الفاتورة مرحلة محاسبيًا بالفعل')
    if x.total<=0: raise HTTPException(400,'لا يمكن ترحيل فاتورة بقيمة صفر أو سالبة')
    ensure_open_period(s,x.date)
    try:
        entry=post_journal(s,u,x.date,'ترحيل فاتورة '+x.number,[(mapped_code(s,'customer_receivable','1100'),x.total,0,'ذمم العملاء'),(mapped_code(s,'customs_revenue','4100'),0,x.total,'إيراد خدمات')])
        x.posted=True; x.status='غير مسددة'; x.paid=0
        s.commit(); audit(s,u,'post','invoice',x.id)
        return {'id':x.id,'posted':True,'journal_entry_id':entry.id}
    except Exception:
        s.rollback(); raise
@app.get('/api/invoices/{invoice_id}')
def invoice(invoice_id:int,s=Depends(db),u=Depends(current_user)):
    x=s.get(Invoice,invoice_id)
    if not x: raise HTTPException(404,'الفاتورة غير موجودة')
    return {'id':x.id,'number':x.number,'date':x.date,'customer_id':x.customer_id,'description':x.description,'total':x.total,'paid':x.paid,'status':x.status,'lines':[{'description':l.description,'qty':l.qty,'unit_price':l.unit_price,'total':l.total} for l in s.query(InvoiceLine).filter_by(invoice_id=x.id).all()]}
@app.get('/api/vouchers')
def vouchers(s=Depends(db),u=Depends(current_user)):
    return [{'id':x.id,'number':x.number,'date':x.date,'voucher_type':x.voucher_type,'cash_box':x.cash_box,'reference':x.reference,'description':x.description,'amount':x.amount,'account_code':x.account_code,'invoice_id':x.invoice_id,'posted':x.posted} for x in s.query(Voucher).order_by(Voucher.id.desc()).all()]
@app.post('/api/vouchers')
def add_voucher(x:VoucherIn,s=Depends(db),u=Depends(current_user)):
    if x.amount<=0: raise HTTPException(400,'المبلغ يجب أن يكون أكبر من صفر')
    if s.query(Voucher).filter_by(number=x.number).first(): raise HTTPException(409,'رقم السند موجود')
    z=Voucher(**x.model_dump()); s.add(z); s.flush(); s.commit(); audit(s,u,'create','voucher',z.id); return {'id':z.id,**x.model_dump(),'posted':False}

@app.post('/api/vouchers/{voucher_id}/post')
def post_voucher(voucher_id:int,s=Depends(db),u=Depends(current_user)):
    if not has_permission(s,u,'accounting','post'): raise HTTPException(403,'لا تملك صلاحية ترحيل السندات')
    x=s.get(Voucher,voucher_id)
    if not x: raise HTTPException(404,'السند غير موجود')
    if x.posted: raise HTTPException(409,'السند مرحل محاسبيًا بالفعل')
    if x.amount<=0: raise HTTPException(400,'المبلغ يجب أن يكون أكبر من صفر')
    if not x.account_code: raise HTTPException(400,'حدد الحساب المقابل قبل الترحيل')
    ensure_open_period(s,x.date)
    if x.invoice_id:
        inv=s.get(Invoice,x.invoice_id)
        if not inv: raise HTTPException(400,'الفاتورة المرتبطة غير موجودة')
        if not inv.posted: raise HTTPException(400,'لا يمكن ترحيل سداد لفاتورة غير مرحلة')
        if x.voucher_type!='قبض': raise HTTPException(400,'ربط الفاتورة متاح لسندات القبض فقط')
        posted_paid=round(sum(v.amount for v in s.query(Voucher).filter(Voucher.invoice_id==inv.id,Voucher.voucher_type=='قبض',Voucher.posted==True).all()),2)
        if round(posted_paid+x.amount,2)>round(inv.total,2): raise HTTPException(400,'قيمة السداد تتجاوز المتبقي على الفاتورة')
    cash_code=mapped_code(s,'cash','1110')
    if x.voucher_type=='قبض': lines=[(cash_code,x.amount,0,x.description),(x.account_code,0,x.amount,x.description)]
    elif x.voucher_type=='صرف': lines=[(x.account_code,x.amount,0,x.description),(cash_code,0,x.amount,x.description)]
    else: lines=[(x.account_code,x.amount,0,x.description),(cash_code,0,x.amount,x.description)]
    try:
        entry=post_journal(s,u,x.date,'ترحيل سند '+x.number,lines); x.posted=True
        if x.invoice_id and x.voucher_type=='قبض':
            inv=s.get(Invoice,x.invoice_id)
            paid=round(sum(v.amount for v in s.query(Voucher).filter(Voucher.invoice_id==inv.id,Voucher.voucher_type=='قبض',Voucher.posted==True).all())+x.amount,2)
            inv.paid=paid; inv.status='مسددة' if paid>=inv.total else 'مسددة جزئيًا'
        s.commit(); audit(s,u,'post','voucher',x.id)
        return {'id':x.id,'posted':True,'journal_entry_id':entry.id}
    except Exception:
        s.rollback(); raise

@app.get('/api/shipments/{shipment_id}/items')
def shipment_items(shipment_id:int,s=Depends(db),u=Depends(current_user)):
    return [{'id':x.id,'description':x.description,'barcode':x.barcode,'qty':x.qty,'cartons':x.cartons,'net_weight':x.net_weight,'unit_price':x.unit_price,'customs_value':x.customs_value} for x in s.query(ShipmentItem).filter_by(shipment_id=shipment_id).all()]
@app.post('/api/shipments/{shipment_id}/items')
def add_shipment_item(shipment_id:int,x:ShipmentItemIn,s=Depends(db),u=Depends(current_user)):
    if not s.get(Shipment,shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    z=ShipmentItem(shipment_id=shipment_id,**x.model_dump()); s.add(z); s.commit(); audit(s,u,'create','shipment_item',z.id); return {'id':z.id,**x.model_dump()}
@app.get('/api/documents')
def documents(shipment_id:int|None=None,s=Depends(db),u=Depends(current_user)):
    q=s.query(Document); q=q.filter_by(shipment_id=shipment_id) if shipment_id else q
    return [{'id':x.id,'shipment_id':x.shipment_id,'doc_type':x.doc_type,'file_name':x.file_name,'notes':x.notes,'uploaded_at':x.uploaded_at.isoformat()} for x in q.order_by(Document.id.desc()).all()]
@app.post('/api/documents')
def add_document(x:DocumentIn,s=Depends(db),u=Depends(current_user)):
    if x.shipment_id and not s.get(Shipment,x.shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    z=Document(**x.model_dump()); s.add(z); s.commit(); audit(s,u,'create','document',z.id); return {'id':z.id,**x.model_dump()}
DOCUMENT_STORE=os.getenv('DOCUMENT_STORE','./data/documents')
pathlib.Path(DOCUMENT_STORE).mkdir(parents=True,exist_ok=True)
ALLOWED_DOCUMENT_EXT={'.pdf','.png','.jpg','.jpeg','.webp','.xlsx','.xls','.csv','.docx','.txt'}
MAX_DOCUMENT_BYTES=int(os.getenv('MAX_DOCUMENT_BYTES',20*1024*1024))

@app.post('/api/documents/{document_id}/file')
async def upload_document_file(document_id:int,file:UploadFile=File(...),s=Depends(db),u=Depends(current_user)):
    doc=s.get(Document,document_id)
    if not doc: raise HTTPException(404,'المستند غير موجود')
    original=pathlib.Path(file.filename or 'document').name
    ext=pathlib.Path(original).suffix.lower()
    if ext not in ALLOWED_DOCUMENT_EXT: raise HTTPException(400,'نوع الملف غير مسموح')
    raw=await file.read(MAX_DOCUMENT_BYTES+1)
    if len(raw)>MAX_DOCUMENT_BYTES: raise HTTPException(413,'حجم الملف يتجاوز الحد المسموح')
    digest=hashlib.sha256(raw).hexdigest()
    stored=f'{digest}{ext}'
    target=pathlib.Path(DOCUMENT_STORE)/stored
    if not target.exists(): target.write_bytes(raw)
    z=DocumentFile(document_id=document_id,stored_name=stored,original_name=original,mime_type=file.content_type or 'application/octet-stream',size_bytes=len(raw),sha256=digest)
    s.add(z); s.commit(); audit(s,u,'upload','document_file',z.id)
    return {'id':z.id,'document_id':document_id,'file_name':original,'size_bytes':len(raw),'sha256':digest}

@app.get('/api/documents/{document_id}/files')
def document_files(document_id:int,s=Depends(db),u=Depends(current_user)):
    return [{'id':x.id,'document_id':x.document_id,'file_name':x.original_name,'mime_type':x.mime_type,'size_bytes':x.size_bytes,'sha256':x.sha256,'uploaded_at':x.uploaded_at.isoformat()} for x in s.query(DocumentFile).filter_by(document_id=document_id).order_by(DocumentFile.id.desc()).all()]

@app.get('/api/document-files/{file_id}/download')
def download_document_file(file_id:int,s=Depends(db),u=Depends(current_user)):
    from fastapi.responses import FileResponse, Response
    z=s.get(DocumentFile,file_id)
    if not z: raise HTTPException(404,'الملف غير موجود')
    path=pathlib.Path(DOCUMENT_STORE)/z.stored_name
    if not path.exists(): raise HTTPException(404,'ملف الأرشيف غير موجود على التخزين')
    return FileResponse(path,media_type=z.mime_type,filename=z.original_name)

@app.get('/api/document-archive/search')
def search_document_archive(q:str='',shipment_id:int|None=None,s=Depends(db),u=Depends(current_user)):
    query=s.query(DocumentFile,Document).join(Document,Document.id==DocumentFile.document_id)
    if shipment_id: query=query.filter(Document.shipment_id==shipment_id)
    if q.strip(): query=query.filter(DocumentFile.original_name.ilike(f'%{q.strip()}%'))
    rows=query.order_by(DocumentFile.id.desc()).limit(300).all()
    return [{'file_id':f.id,'document_id':d.id,'shipment_id':d.shipment_id,'document_type':d.doc_type,'file_name':f.original_name,'size_bytes':f.size_bytes,'sha256':f.sha256,'uploaded_at':f.uploaded_at.isoformat()} for f,d in rows]


@app.post('/api/customers/{customer_id}/services/generate-invoice')
def generate_customer_service_invoice(customer_id:int,date:str,number:str,s=Depends(db),u=Depends(current_user)):
    if not has_permission(s,u,'accounting','create'): raise HTTPException(403,'لا تملك صلاحية إنشاء الفواتير')
    c=s.get(Customer,customer_id)
    if not c: raise HTTPException(404,'العميل غير موجود')
    if s.query(Invoice).filter_by(number=number).first(): raise HTTPException(409,'رقم الفاتورة موجود')
    rows=s.query(CustomerService,Service).join(Service,Service.id==CustomerService.service_id).filter(CustomerService.customer_id==customer_id,CustomerService.invoice_id.is_(None),CustomerService.status!='ملغاة').order_by(CustomerService.date,CustomerService.id).all()
    if not rows: raise HTTPException(400,'لا توجد خدمات غير مفوترة لهذا العميل')
    total=round(sum(cs.quantity*cs.unit_price for cs,sv in rows),2)
    inv=Invoice(number=number,date=date,customer_id=customer_id,description='فاتورة خدمات مجمعة - '+c.name,total=total)
    s.add(inv); s.flush()
    for cs,sv in rows:
        line_total=round(cs.quantity*cs.unit_price,2)
        s.add(InvoiceLine(invoice_id=inv.id,description=sv.name+(' - '+cs.description if cs.description else ''),qty=cs.quantity,unit_price=cs.unit_price,total=line_total))
        cs.invoice_id=inv.id
        cs.status='مفوترة'
    s.commit(); audit(s,u,'create','service_invoice',inv.id)
    return {'id':inv.id,'number':inv.number,'customer_id':customer_id,'service_count':len(rows),'total':total,'posted':False}

@app.post('/api/customers/{customer_id}/claims/{claim_id}/status')
def update_claim_status(customer_id:int,claim_id:int,status:str,s=Depends(db),u=Depends(current_user)):
    allowed={'جديدة','قيد المتابعة','مطالبة مرسلة','مدفوعة','ملغاة'}
    if status not in allowed: raise HTTPException(400,'حالة المطالبة غير صالحة')
    z=s.get(Claim,claim_id)
    if not z or z.customer_id!=customer_id: raise HTTPException(404,'المطالبة غير موجودة')
    z.status=status; s.commit(); audit(s,u,'status','claim',z.id)
    return {'id':z.id,'customer_id':customer_id,'status':z.status}

def customer_posted_financials(s, customer_id:int, date_from:str|None=None, date_to:str|None=None):
    """Authoritative customer ledger: only posted invoices and posted receipt vouchers count."""
    iq=s.query(Invoice).filter(Invoice.customer_id==customer_id, Invoice.posted==True)
    if date_from: iq=iq.filter(Invoice.date>=date_from)
    if date_to: iq=iq.filter(Invoice.date<=date_to)
    invoices=iq.order_by(Invoice.date,Invoice.id).all()
    vq=s.query(Voucher).join(Invoice,Invoice.id==Voucher.invoice_id).filter(
        Invoice.customer_id==customer_id, Voucher.posted==True, Voucher.voucher_type=='قبض')
    if date_from: vq=vq.filter(Voucher.date>=date_from)
    if date_to: vq=vq.filter(Voucher.date<=date_to)
    receipts=vq.order_by(Voucher.date,Voucher.id).all()
    events=[(x.date,0,x.id,x) for x in invoices] + [(x.date,1,x.id,x) for x in receipts]
    events.sort(key=lambda e:(e[0],e[1],e[2]))
    rows=[]; balance=0.0; invoiced=0.0; paid=0.0
    for _,kind,_,obj in events:
        if kind==0:
            amount=round(obj.total,2); invoiced+=amount; balance=round(balance+amount,2)
            rows.append({'date':obj.date,'type':'فاتورة','number':obj.number,'reference':obj.number,'debit':amount,'credit':0,'balance':balance,'invoice_id':obj.id,'posted':True})
        else:
            amount=round(obj.amount,2); paid+=amount; balance=round(balance-amount,2)
            rows.append({'date':obj.date,'type':'سداد','number':obj.number,'reference':obj.reference,'debit':0,'credit':amount,'balance':balance,'invoice_id':obj.invoice_id,'voucher_id':obj.id,'posted':True})
    return invoices, receipts, rows, round(invoiced,2), round(paid,2), round(balance,2)

@app.get('/api/customers/{customer_id}/statement')
def customer_statement(customer_id:int,date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    c=s.get(Customer,customer_id)
    if not c: raise HTTPException(404,'العميل غير موجود')
    if date_from and date_to and date_from>date_to: raise HTTPException(400,'تاريخ البداية أكبر من النهاية')
    invoices, receipts, rows, invoiced, paid, balance=customer_posted_financials(s,customer_id,date_from,date_to)
    return {'customer':{'id':c.id,'name':c.name,'phone':c.phone,'tax_no':c.tax_no},
            'filters':{'date_from':date_from,'date_to':date_to},'rows':rows,
            'summary':{'invoiced':invoiced,'paid':paid,'balance':balance,
                       'invoice_count':len(invoices),'receipt_count':len(receipts)},'balance':balance}

@app.get('/api/customers/{customer_id}/financial-summary')
def customer_financial_summary(customer_id:int,s=Depends(db),u=Depends(current_user)):
    c=s.get(Customer,customer_id)
    if not c: raise HTTPException(404,'العميل غير موجود')
    invoices, receipts, _, total_invoiced, total_paid, outstanding=customer_posted_financials(s,customer_id)
    return {'customer_id':customer_id,'customer_name':c.name,'invoice_count':len(invoices),
            'receipt_count':len(receipts),'total_invoiced':total_invoiced,'total_paid':total_paid,
            'outstanding':outstanding,'status':'مسدد' if outstanding<=0 else 'عليه رصيد'}

@app.get('/api/customers/financial-summaries')
def customer_financial_summaries(s=Depends(db),u=Depends(current_user)):
    out=[]
    for c in s.query(Customer).order_by(Customer.name).all():
        invoices, receipts, _, total_invoiced, total_paid, outstanding=customer_posted_financials(s,c.id)
        last_date=None
        dates=[x.date for x in invoices+receipts if x.date]
        if dates: last_date=max(dates)
        status='مسدد' if outstanding<=0 else 'عليه رصيد'
        out.append({'customer_id':c.id,'customer_name':c.name,'phone':c.phone,
                    'invoice_count':len(invoices),'receipt_count':len(receipts),
                    'total_invoiced':total_invoiced,'total_paid':total_paid,
                    'outstanding':outstanding,'status':status,'last_transaction_date':last_date})
    return {'count':len(out),'rows':out}

@app.get('/api/customers/{customer_id}/importers')
def customer_importers(customer_id:int,s=Depends(db),u=Depends(current_user)):
    if not s.get(Customer,customer_id): raise HTTPException(404,'العميل غير موجود')
    return [x.__dict__|{} for x in s.query(CustomerImporter).filter_by(customer_id=customer_id).order_by(CustomerImporter.id.desc()).all()]

@app.post('/api/customers/{customer_id}/importers')
def add_customer_importer(customer_id:int,x:CustomerImporterIn,s=Depends(db),u=Depends(current_user)):
    if not s.get(Customer,customer_id): raise HTTPException(404,'العميل غير موجود')
    z=CustomerImporter(customer_id=customer_id,**x.model_dump()); s.add(z); s.commit(); audit(s,u,'create','customer_importer',z.id); return {'id':z.id,'customer_id':customer_id,**x.model_dump()}

@app.get('/api/services')
def services(s=Depends(db),u=Depends(current_user)):
    return [x.__dict__|{} for x in s.query(Service).order_by(Service.name).all()]

@app.post('/api/services')
def add_service(x:ServiceIn,s=Depends(db),u=Depends(current_user)):
    if s.query(Service).filter_by(code=x.code).first(): raise HTTPException(409,'رمز الخدمة موجود')
    z=Service(**x.model_dump()); s.add(z); s.commit(); audit(s,u,'create','service',z.id); return {'id':z.id,**x.model_dump()}

@app.get('/api/customers/{customer_id}/services')
def customer_services(customer_id:int,s=Depends(db),u=Depends(current_user)):
    if not s.get(Customer,customer_id): raise HTTPException(404,'العميل غير موجود')
    q=s.query(CustomerService,Service).join(Service,Service.id==CustomerService.service_id).filter(CustomerService.customer_id==customer_id).order_by(CustomerService.date.desc(),CustomerService.id.desc()).all()
    return [{'id':cs.id,'customer_id':cs.customer_id,'service_id':cs.service_id,'service_name':sv.name,'service_type':sv.service_type,'date':cs.date,'quantity':cs.quantity,'unit_price':cs.unit_price,'total':round(cs.quantity*cs.unit_price,2),'description':cs.description,'invoice_id':cs.invoice_id,'status':cs.status} for cs,sv in q]

@app.post('/api/customers/{customer_id}/services')
def add_customer_service(customer_id:int,x:CustomerServiceIn,s=Depends(db),u=Depends(current_user)):
    if not s.get(Customer,customer_id): raise HTTPException(404,'العميل غير موجود')
    sv=s.get(Service,x.service_id)
    if not sv: raise HTTPException(404,'الخدمة غير موجودة')
    price=x.unit_price if x.unit_price else sv.default_price
    z=CustomerService(customer_id=customer_id,service_id=x.service_id,date=x.date,quantity=x.quantity,unit_price=price,description=x.description,invoice_id=x.invoice_id,status=x.status)
    s.add(z); s.commit(); audit(s,u,'create','customer_service',z.id); return {'id':z.id,'total':round(z.quantity*z.unit_price,2)}

@app.get('/api/claims')
def claims(customer_id:int|None=None,s=Depends(db),u=Depends(current_user)):
    q=s.query(Claim);
    if customer_id: q=q.filter_by(customer_id=customer_id)
    return [x.__dict__|{} for x in q.order_by(Claim.id.desc()).all()]

@app.post('/api/customers/{customer_id}/claims')
def add_claim(customer_id:int,x:ClaimIn,s=Depends(db),u=Depends(current_user)):
    if not s.get(Customer,customer_id): raise HTTPException(404,'العميل غير موجود')
    if s.query(Claim).filter_by(claim_no=x.claim_no).first(): raise HTTPException(409,'رقم المطالبة موجود')
    if x.shipment_id and not s.get(Shipment,x.shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    z=Claim(customer_id=customer_id,created_by=u.id,**x.model_dump()); s.add(z); s.commit(); audit(s,u,'create','claim',z.id); return {'id':z.id,**x.model_dump()}

@app.get('/api/suppliers')
def suppliers(s=Depends(db),u=Depends(current_user)):
    return [{'id':x.id,'name':x.name,'phone':x.phone,'tax_no':x.tax_no,'notes':x.notes} for x in s.query(Supplier).order_by(Supplier.name).all()]

@app.post('/api/suppliers')
def add_supplier(x:SupplierIn,s=Depends(db),u=Depends(current_user)):
    z=Supplier(**x.model_dump()); s.add(z); s.commit(); audit(s,u,'create','supplier',z.id); return {'id':z.id,**x.model_dump()}

@app.get('/api/purchases')
def purchases(s=Depends(db),u=Depends(current_user)):
    return [{'id':x.id,'number':x.number,'date':x.date,'supplier_id':x.supplier_id,'description':x.description,'total':x.total,'posted':x.posted} for x in s.query(Purchase).order_by(Purchase.id.desc()).all()]

@app.post('/api/purchases')
def add_purchase(x:PurchaseIn,s=Depends(db),u=Depends(current_user)):
    if s.query(Purchase).filter_by(number=x.number).first(): raise HTTPException(409,'رقم المشتريات موجود')
    if not x.lines: raise HTTPException(400,'المشتريات يجب أن تحتوي على بند')
    total=round(sum(l.qty*l.unit_price for l in x.lines),2)
    z=Purchase(number=x.number,date=x.date,supplier_id=x.supplier_id,description=x.description,total=total); s.add(z); s.flush()
    for l in x.lines: s.add(PurchaseLine(purchase_id=z.id,description=l.description,qty=l.qty,unit_price=l.unit_price,total=round(l.qty*l.unit_price,2)))
    s.commit(); audit(s,u,'create','purchase',z.id); return {'id':z.id,'number':z.number,'total':total,'posted':False}

@app.post('/api/purchases/{purchase_id}/post')
def post_purchase(purchase_id:int,s=Depends(db),u=Depends(current_user)):
    if not has_permission(s,u,'accounting','post'): raise HTTPException(403,'لا تملك صلاحية ترحيل المشتريات')
    x=s.get(Purchase,purchase_id)
    if not x: raise HTTPException(404,'المشتريات غير موجودة')
    if x.posted: raise HTTPException(409,'المشتريات مرحلة بالفعل')
    ensure_open_period(s,x.date)
    post_journal(s,u,x.date,'ترحيل مشتريات '+x.number,[(mapped_code(s,'inventory','1200'),x.total,0,'مخزون/مشتريات'),(mapped_code(s,'supplier_payable','2100'),0,x.total,'ذمم الموردين')])
    x.posted=True; s.commit(); audit(s,u,'post','purchase',x.id); return {'id':x.id,'posted':True}

@app.get('/api/expenses')
def expenses(expense_type:str|None=None,date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    q=s.query(Expense)
    if expense_type: q=q.filter(Expense.expense_type==expense_type)
    if date_from: q=q.filter(Expense.date>=date_from)
    if date_to: q=q.filter(Expense.date<=date_to)
    return [{'id':x.id,'number':x.number,'date':x.date,'expense_type':x.expense_type,'description':x.description,'amount':round(x.amount,2),'expense_account_code':x.expense_account_code,'payment_account_code':x.payment_account_code,'supplier_id':x.supplier_id,'shipment_id':x.shipment_id,'reference':x.reference,'posted':x.posted} for x in q.order_by(Expense.date.desc(),Expense.id.desc()).all()]

@app.post('/api/expenses')
def add_expense(x:ExpenseIn,s=Depends(db),u=Depends(current_user)):
    if x.amount<=0: raise HTTPException(400,'قيمة المصروف يجب أن تكون أكبر من صفر')
    if s.query(Expense).filter_by(number=x.number).first(): raise HTTPException(409,'رقم المصروف موجود')
    if x.supplier_id and not s.get(Supplier,x.supplier_id): raise HTTPException(404,'المورد غير موجود')
    if x.shipment_id and not s.get(Shipment,x.shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    type_map={'إدارية':'admin_expense','ادارية':'admin_expense','تشغيلية':'operating_expense','تسهيلات معاملات':'facilitation_expense','تسهيلات':'facilitation_expense'}
    exp_code=x.expense_account_code or mapped_code(s,type_map.get(x.expense_type,'operating_expense'),'5100')
    pay_code=x.payment_account_code or mapped_code(s,'cash','1110')
    if not s.query(Account).filter_by(code=exp_code).first(): raise HTTPException(400,'حساب المصروف غير موجود')
    if not s.query(Account).filter_by(code=pay_code).first(): raise HTTPException(400,'حساب الدفع غير موجود')
    z=Expense(number=x.number,date=x.date,expense_type=x.expense_type,description=x.description,amount=round(x.amount,2),expense_account_code=exp_code,payment_account_code=pay_code,supplier_id=x.supplier_id,shipment_id=x.shipment_id,reference=x.reference,posted=False)
    s.add(z); s.commit(); audit(s,u,'create','expense',z.id)
    return {'id':z.id,'number':z.number,'amount':z.amount,'posted':False}

@app.post('/api/expenses/{expense_id}/post')
def post_expense(expense_id:int,s=Depends(db),u=Depends(current_user)):
    if not has_permission(s,u,'accounting','post'): raise HTTPException(403,'لا تملك صلاحية ترحيل المصروفات')
    x=s.get(Expense,expense_id)
    if not x: raise HTTPException(404,'المصروف غير موجود')
    if x.posted: raise HTTPException(409,'المصروف مرحل محاسبيًا بالفعل')
    if x.amount<=0: raise HTTPException(400,'قيمة المصروف غير صحيحة')
    if not s.query(Account).filter_by(code=x.expense_account_code).first(): raise HTTPException(400,'حساب المصروف غير موجود')
    if not s.query(Account).filter_by(code=x.payment_account_code).first(): raise HTTPException(400,'حساب الدفع غير موجود')
    ensure_open_period(s,x.date)
    try:
        entry=post_journal(s,u,x.date,'ترحيل مصروف '+x.number,[(x.expense_account_code,x.amount,0,x.description or x.expense_type),(x.payment_account_code,0,x.amount,x.description or x.expense_type)])
        x.posted=True; s.commit(); audit(s,u,'post','expense',x.id)
        return {'id':x.id,'posted':True,'journal_entry_id':entry.id}
    except Exception:
        s.rollback(); raise

@app.get('/api/reports/expenses')
def expense_report(date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    validate_iso_date_range(date_from,date_to)
    q=s.query(Expense).filter(Expense.posted==True)
    if date_from: q=q.filter(Expense.date>=date_from)
    if date_to: q=q.filter(Expense.date<=date_to)
    rows=q.order_by(Expense.date,Expense.id).all()
    by_type={} ; by_account={}
    for x in rows:
        by_type[x.expense_type]=round(by_type.get(x.expense_type,0)+x.amount,2)
        by_account[x.expense_account_code]=round(by_account.get(x.expense_account_code,0)+x.amount,2)
    return {'date_from':date_from,'date_to':date_to,'count':len(rows),'total':round(sum(x.amount for x in rows),2),'by_type':[{'expense_type':k,'total':v} for k,v in sorted(by_type.items())],'by_account':[{'account_code':k,'total':v} for k,v in sorted(by_account.items())],'rows':[{'id':x.id,'number':x.number,'date':x.date,'expense_type':x.expense_type,'description':x.description,'amount':round(x.amount,2),'expense_account_code':x.expense_account_code,'payment_account_code':x.payment_account_code,'reference':x.reference,'supplier_id':x.supplier_id,'shipment_id':x.shipment_id} for x in rows]}

@app.get('/api/admin/account-mappings')
def account_mappings(s=Depends(db),u=Depends(manager)):
    return [{'key':x.key,'account_code':x.account_code,'description':x.description} for x in s.query(AccountMapping).order_by(AccountMapping.key).all()]

@app.put('/api/admin/account-mappings/{key}')
def set_account_mapping(key:str,x:MappingIn,s=Depends(db),u=Depends(manager)):
    if not s.query(Account).filter_by(code=x.account_code).first(): raise HTTPException(400,'الحساب غير موجود في دليل الحسابات')
    z=s.get(AccountMapping,key) or AccountMapping(key=key); z.account_code=x.account_code; z.description=x.description; s.add(z); s.commit(); audit(s,u,'update','account_mapping',key); return {'key':key,'account_code':z.account_code,'description':z.description}

class ReverseIn(BaseModel):
    reason:str=Field(min_length=3,max_length=300)

@app.post('/api/journal/{entry_id}/reverse')
def reverse_journal(entry_id:int,x:ReverseIn,s=Depends(db),u=Depends(current_user)):
    if not has_permission(s,u,'accounting','post'): raise HTTPException(403,'لا تملك صلاحية عكس القيود')
    src=s.get(JournalEntry,entry_id)
    if not src: raise HTTPException(404,'القيد غير موجود')
    ensure_open_period(s, datetime.now(timezone.utc).date().isoformat())
    existing=s.query(JournalEntry).filter(JournalEntry.description.like(f'عكس القيد {entry_id}:%')).first()
    if existing: raise HTTPException(409,'تم عكس هذا القيد مسبقًا')
    lines=[(l.account_code,l.credit,l.debit,'عكس: '+(l.description or '')) for l in src.lines]
    z=post_journal(s,u,datetime.now(timezone.utc).date().isoformat(),f'عكس القيد {entry_id}: {x.reason}',lines)
    s.commit(); audit(s,u,'reverse','journal_entry',entry_id)
    return {'id':z.id,'reversed_entry_id':entry_id,'status':'posted'}

@app.get('/api/admin/fiscal-periods')
def fiscal_periods(s=Depends(db),u=Depends(manager)):
    return [{'id':x.id,'name':x.name,'start_date':x.start_date,'end_date':x.end_date,'closed':x.closed} for x in s.query(FiscalPeriod).order_by(FiscalPeriod.start_date.desc()).all()]

@app.post('/api/admin/fiscal-periods')
def add_period(x:PeriodIn,s=Depends(db),u=Depends(manager)):
    if s.query(FiscalPeriod).filter_by(name=x.name).first(): raise HTTPException(409,'الفترة موجودة')
    z=FiscalPeriod(**x.model_dump()); s.add(z); s.commit(); audit(s,u,'create','fiscal_period',z.id); return {'id':z.id,**x.model_dump()}

@app.put('/api/admin/fiscal-periods/{period_id}/close')
def close_period(period_id:int,s=Depends(db),u=Depends(manager)):
    z=s.get(FiscalPeriod,period_id)
    if not z: raise HTTPException(404,'الفترة غير موجودة')
    z.closed=True; s.commit(); audit(s,u,'close','fiscal_period',z.id); return {'id':z.id,'closed':True}

# ===== V0.9 AI layer =====
class AIProvider(Base):
    __tablename__='ai_providers'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    name:Mapped[str]=mapped_column(String(120),unique=True)
    provider_type:Mapped[str]=mapped_column(String(40),default='local')
    endpoint:Mapped[str]=mapped_column(String(300),default='')
    model:Mapped[str]=mapped_column(String(160),default='')
    enabled:Mapped[bool]=mapped_column(Boolean,default=True)
    is_default:Mapped[bool]=mapped_column(Boolean,default=False)
class AIExtraction(Base):
    __tablename__='ai_extractions'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    shipment_id:Mapped[int|None]=mapped_column(ForeignKey('shipments.id'),nullable=True)
    document_type:Mapped[str]=mapped_column(String(80),default='')
    file_name:Mapped[str]=mapped_column(String(250),default='')
    sha256:Mapped[str]=mapped_column(String(64),default='')
    extracted_json:Mapped[str]=mapped_column(Text,default='{}')
    confidence:Mapped[float]=mapped_column(Float,default=0)
    status:Mapped[str]=mapped_column(String(40),default='مراجعة')
    created_by:Mapped[int]=mapped_column(Integer)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))
class AIReview(Base):
    __tablename__='ai_reviews'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    extraction_id:Mapped[int]=mapped_column(ForeignKey('ai_extractions.id'),index=True)
    decision:Mapped[str]=mapped_column(String(40),default='مراجعة')
    notes:Mapped[str]=mapped_column(Text,default='')
    approved_by:Mapped[int]=mapped_column(Integer)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))
Base.metadata.create_all(engine)
class AITextIn(BaseModel):
    shipment_id:int|None=None
    document_type:str='مستند'
    text:str
    file_name:str=''
class AIReviewIn(BaseModel):
    decision:str
    notes:str=''
def _extract_fields(text:str):
    import re
    patterns={
      'invoice_no':r'(?:invoice|فاتورة|رقم الفاتورة)\s*[:#\-]?\s*([A-Za-z0-9\-/]+)',
      'declaration_no':r'(?:declaration|البيان|رقم البيان)\s*[:#\-]?\s*([A-Za-z0-9\-/]+)',
      'bill_of_lading':r'(?:bill of lading|b/l|بوليصة الشحن)\s*[:#\-]?\s*([A-Za-z0-9\-/]+)',
      'currency':r'(?:currency|العملة)\s*[:#\-]?\s*([A-Za-z]{3}|ريال|دولار)',
      'total':r'(?:total|الإجمالي|المجموع)\s*[:#\-]?\s*([0-9][0-9,]*(?:\.[0-9]+)?)',
      'net_weight':r'(?:net weight|الوزن الصافي)\s*[:#\-]?\s*([0-9][0-9,]*(?:\.[0-9]+)?)',
    }
    out={}
    for k,pat in patterns.items():
        m=re.search(pat,text,re.I)
        if m: out[k]=m.group(1).replace(',','')
    return out
@app.get('/api/ai/providers')
def ai_providers(s=Depends(db),u=Depends(current_user)):
    return [{'id':x.id,'name':x.name,'provider_type':x.provider_type,'endpoint':x.endpoint,'model':x.model,'enabled':x.enabled,'is_default':x.is_default} for x in s.query(AIProvider).all()]
@app.post('/api/ai/providers')
def add_ai_provider(x:dict,s=Depends(db),u=Depends(manager)):
    z=AIProvider(name=str(x.get('name','Local AI')),provider_type=str(x.get('provider_type','local')),endpoint=str(x.get('endpoint','')),model=str(x.get('model','')),enabled=bool(x.get('enabled',True)),is_default=bool(x.get('is_default',False)))
    if z.is_default: s.query(AIProvider).update({AIProvider.is_default:False})
    s.add(z); s.commit(); audit(s,u,'create','ai_provider',z.id)
    return {'id':z.id,'name':z.name,'provider_type':z.provider_type,'model':z.model}
@app.post('/api/ai/extract-text')
def ai_extract_text(x:AITextIn,s=Depends(db),u=Depends(current_user)):
    import hashlib, json
    data=_extract_fields(x.text); confidence=100.0 if data else 0.0
    z=AIExtraction(shipment_id=x.shipment_id,document_type=x.document_type,file_name=x.file_name,sha256=hashlib.sha256(x.text.encode('utf-8')).hexdigest(),extracted_json=json.dumps(data,ensure_ascii=False),confidence=confidence,status='مراجعة',created_by=u.id)
    s.add(z); s.commit(); audit(s,u,'create','ai_extraction',z.id)
    return {'id':z.id,'fields':data,'confidence':confidence,'status':'مراجعة','requires_review':True}
@app.post('/api/ai/extract-file')
async def ai_extract_file(file:UploadFile=File(...),shipment_id:int|None=None,document_type:str='مستند',s=Depends(db),u=Depends(current_user)):
    import hashlib, json
    raw=await file.read()
    try: text=raw.decode('utf-8')
    except UnicodeDecodeError: text=''
    data=_extract_fields(text) if text else {}; confidence=100.0 if data else 0.0
    z=AIExtraction(shipment_id=shipment_id,document_type=document_type,file_name=file.filename or '',sha256=hashlib.sha256(raw).hexdigest(),extracted_json=json.dumps(data,ensure_ascii=False),confidence=confidence,status='مراجعة',created_by=u.id)
    s.add(z); s.commit(); audit(s,u,'create','ai_extraction',z.id)
    return {'id':z.id,'file_name':z.file_name,'fields':data,'confidence':confidence,'status':'مراجعة','requires_review':True,'note':'PDF/JPG تحتاج OCR/قارئ مستندات مفعّل في مزود الذكاء الاصطناعي.'}
@app.get('/api/ai/extractions')
def ai_extractions(shipment_id:int|None=None,s=Depends(db),u=Depends(current_user)):
    import json
    q=s.query(AIExtraction).order_by(AIExtraction.id.desc())
    if shipment_id is not None: q=q.filter_by(shipment_id=shipment_id)
    return [{'id':x.id,'shipment_id':x.shipment_id,'document_type':x.document_type,'file_name':x.file_name,'fields':json.loads(x.extracted_json),'confidence':x.confidence,'status':x.status,'created_at':x.created_at.isoformat()} for x in q.limit(200).all()]
@app.post('/api/ai/extractions/{extraction_id}/review')
def review_extraction(extraction_id:int,x:AIReviewIn,s=Depends(db),u=Depends(current_user)):
    if x.decision not in {'مقبول','مرفوض','مراجعة'}: raise HTTPException(400,'قرار المراجعة غير صحيح')
    z=s.get(AIExtraction,extraction_id)
    if not z: raise HTTPException(404,'نتيجة الاستخراج غير موجودة')
    z.status=x.decision; s.add(AIReview(extraction_id=z.id,decision=x.decision,notes=x.notes,approved_by=u.id)); s.commit(); audit(s,u,'review','ai_extraction',z.id)
    return {'ok':True,'id':z.id,'status':z.status}

# ===== V1.4 OCR layer =====
def _ocr_image_bytes(raw: bytes, lang: str='ara+eng'):
    import tempfile, subprocess, os
    suffix='.png'
    with tempfile.TemporaryDirectory() as td:
        src=os.path.join(td,'input'+suffix)
        out=os.path.join(td,'ocr')
        with open(src,'wb') as f: f.write(raw)
        cmd=['tesseract',src,out,'-l',lang,'--psm','6']
        try:
            r=subprocess.run(cmd,capture_output=True,text=True,timeout=120)
        except FileNotFoundError:
            raise HTTPException(500,'محرك OCR (Tesseract) غير مثبت على الخادم')
        except subprocess.TimeoutExpired:
            raise HTTPException(408,'انتهت مهلة قراءة الصورة بواسطة OCR')
        if r.returncode!=0:
            raise HTTPException(400,'تعذر قراءة الصورة بواسطة OCR: '+(r.stderr[-500:] or 'خطأ غير معروف'))
        txt_path=out+'.txt'
        text=Path(txt_path).read_text(encoding='utf-8',errors='ignore') if os.path.exists(txt_path) else ''
        return text

def _ocr_pdf_bytes(raw: bytes, lang: str='ara+eng', max_pages: int=20):
    import tempfile, subprocess, os, glob
    with tempfile.TemporaryDirectory() as td:
        pdf=os.path.join(td,'input.pdf')
        with open(pdf,'wb') as f: f.write(raw)
        prefix=os.path.join(td,'page')
        cmd=['pdftoppm','-r','200','-png','-f','1','-l',str(max_pages),pdf,prefix]
        try: r=subprocess.run(cmd,capture_output=True,text=True,timeout=240)
        except FileNotFoundError: raise HTTPException(500,'محول PDF إلى صور (pdftoppm) غير مثبت')
        except subprocess.TimeoutExpired: raise HTTPException(408,'انتهت مهلة تحويل PDF إلى صور')
        if r.returncode!=0: raise HTTPException(400,'تعذر تحويل PDF إلى صور')
        pages=sorted(glob.glob(prefix+'-*.png'))
        texts=[]
        for img in pages:
            with open(img,'rb') as f: texts.append(_ocr_image_bytes(f.read(),lang))
        return '\n\n'.join(texts), len(pages)

@app.post('/api/ai/ocr-image')
async def ocr_image(file:UploadFile=File(...), shipment_id:int|None=None, document_type:str='مستند', lang:str='ara+eng', s=Depends(db), u=Depends(current_user)):
    import hashlib, json
    raw=await file.read()
    if len(raw)>15*1024*1024: raise HTTPException(413,'حجم الصورة يتجاوز 15MB')
    text=_ocr_image_bytes(raw,lang)
    data=_extract_fields(text)
    confidence=min(100.0, round(len(data)/8*100,2)) if data else (50.0 if text.strip() else 0.0)
    z=AIExtraction(shipment_id=shipment_id,document_type=document_type,file_name=file.filename or '',sha256=hashlib.sha256(raw).hexdigest(),extracted_json=json.dumps(data,ensure_ascii=False),confidence=confidence,status='مراجعة',created_by=u.id)
    s.add(z); s.commit(); audit(s,u,'ocr_image','ai_extraction',z.id)
    return {'id':z.id,'file_name':z.file_name,'characters':len(text),'text':text[:50000],'extracted':data,'confidence':confidence,'status':'مراجعة','requires_review':True}

@app.post('/api/shipments/{shipment_id}/ocr-document')
async def ocr_document(shipment_id:int, document_type:str='مستند', file:UploadFile=File(...), lang:str='ara+eng', max_pages:int=20, s=Depends(db), u=Depends(current_user)):
    import hashlib, json
    if not s.get(Shipment,shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    raw=await file.read()
    name=(file.filename or '').lower()
    if len(raw)>30*1024*1024: raise HTTPException(413,'حجم الملف يتجاوز 30MB')
    if name.endswith('.pdf'):
        text,pages=_ocr_pdf_bytes(raw,lang,max(1,min(max_pages,20)))
    else:
        text=_ocr_image_bytes(raw,lang); pages=1
    data=_extract_fields(text)
    confidence=min(100.0, round(len(data)/8*100,2)) if data else (50.0 if text.strip() else 0.0)
    z=AIExtraction(shipment_id=shipment_id,document_type=document_type,file_name=file.filename or '',sha256=hashlib.sha256(raw).hexdigest(),extracted_json=json.dumps(data,ensure_ascii=False),confidence=confidence,status='مراجعة',created_by=u.id)
    s.add(z); s.commit(); audit(s,u,'ocr_document','ai_extraction',z.id)
    return {'id':z.id,'shipment_id':shipment_id,'file_name':z.file_name,'pages':pages,'characters':len(text),'text':text[:50000],'extracted':data,'confidence':confidence,'status':'مراجعة','requires_review':True}

@app.post('/api/shipments/{shipment_id}/ocr-to-items')
async def ocr_to_items(shipment_id:int, document_type:str='فاتورة', file:UploadFile=File(...), lang:str='ara+eng', s=Depends(db), u=Depends(current_user)):
    if not s.get(Shipment,shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    raw=await file.read(); name=(file.filename or '').lower()
    if name.endswith('.pdf'): text,pages=_ocr_pdf_bytes(raw,lang,20)
    else: text=_ocr_image_bytes(raw,lang); pages=1
    # Conservative row detection: only create candidates from lines containing numeric quantity/price.
    import re, hashlib, json
    candidates=[]
    for i,line in enumerate(text.splitlines(),1):
        line=' '.join(line.split())
        if not line: continue
        nums=re.findall(r'(?<!\w)(\d+(?:[.,]\d+)?)(?!\w)',line)
        if len(nums)>=2 and any(ch.isalpha() or '\u0600'<=ch<='\u06ff' for ch in line):
            desc=re.sub(r'\d+(?:[.,]\d+)?',' ',line).strip(' -|:;')[:300]
            vals=[float(x.replace(',','')) for x in nums[-3:]]
            candidates.append({'line_no':i,'description':desc,'qty':vals[0] if vals else 0,'unit_price':vals[-1] if vals else 0,'raw':line})
    return {'shipment_id':shipment_id,'document_type':document_type,'pages':pages,'candidates':candidates[:500],'candidate_count':len(candidates),'message':'تم إنشاء مرشحين فقط؛ يجب اعتمادهم ومراجعتهم قبل إدخالهم نهائيًا.'}

@app.get('/api/ai/status')
def ai_status(s=Depends(db),u=Depends(current_user)):
    default=s.query(AIProvider).filter_by(is_default=True,enabled=True).first()
    return {'enabled':True,'mode':'local-first','provider':default.name if default else 'محلل محلي مدمج','external_api_required':False,'human_approval_for_actions':True}

@app.get('/api/reports/account-ledger/{account_code}')
def account_ledger(account_code:str,s=Depends(db),u=Depends(current_user)):
    account=s.query(Account).filter_by(code=account_code).first()
    rows=[]; balance=0.0
    q=s.query(JournalLine,JournalEntry).join(JournalEntry,JournalEntry.id==JournalLine.entry_id).filter(JournalLine.account_code==account_code).order_by(JournalEntry.date,JournalEntry.id,JournalLine.id)
    for l,e in q.all():
        balance=round(balance+l.debit-l.credit,2); rows.append({'date':e.date,'description':e.description,'debit':l.debit,'credit':l.credit,'balance':balance,'entry_id':e.id})
    return {'account':{'code':account_code,'name':account.name if account else 'غير معرف'},'rows':rows,'balance':balance}

@app.get('/api/reports/summary')
def report_summary(s=Depends(db),u=Depends(current_user)):
    invoices_total=round(sum(x.total for x in s.query(Invoice).all()),2); paid=round(sum(x.paid for x in s.query(Invoice).all()),2); vouchers=round(sum(x.amount for x in s.query(Voucher).all()),2)
    return {'invoices_total':invoices_total,'receivables':round(invoices_total-paid,2),'vouchers_total':vouchers,'customers':s.query(Customer).count(),'shipments':s.query(Shipment).count(),'journal_entries':s.query(JournalEntry).count()}



# ===== V2.8 unified financial reporting =====
def _journal_query(s, date_from=None, date_to=None):
    q=s.query(JournalLine,JournalEntry).join(JournalEntry,JournalEntry.id==JournalLine.entry_id)
    if date_from: q=q.filter(JournalEntry.date>=date_from)
    if date_to: q=q.filter(JournalEntry.date<=date_to)
    return q.order_by(JournalEntry.date,JournalEntry.id,JournalLine.id)

def _posted_receipts_for_customer(s, customer_id, date_from=None, date_to=None):
    q=s.query(Voucher).filter(Voucher.invoice_id.isnot(None),Voucher.voucher_type=='قبض',Voucher.posted==True)
    if date_from: q=q.filter(Voucher.date>=date_from)
    if date_to: q=q.filter(Voucher.date<=date_to)
    out=[]
    for v in q.order_by(Voucher.date,Voucher.id).all():
        inv=s.get(Invoice,v.invoice_id)
        if inv and inv.customer_id==customer_id: out.append(v)
    return out

@app.get('/api/reports/trial-balance-v2')
def trial_balance_v2(date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    rows={a.code:{'code':a.code,'name':a.name,'account_type':a.account_type,'debit':0.0,'credit':0.0} for a in s.query(Account).all()}
    for l,e in _journal_query(s,date_from,date_to).all():
        rows.setdefault(l.account_code,{'code':l.account_code,'name':'غير معرف','account_type':'unknown','debit':0.0,'credit':0.0})
        rows[l.account_code]['debit']+=l.debit; rows[l.account_code]['credit']+=l.credit
    out=[]
    for x in rows.values():
        x['debit']=round(x['debit'],2); x['credit']=round(x['credit'],2); x['balance']=round(x['debit']-x['credit'],2)
        if x['debit'] or x['credit']: out.append(x)
    return {'date_from':date_from,'date_to':date_to,'rows':out,'total_debit':round(sum(x['debit'] for x in out),2),'total_credit':round(sum(x['credit'] for x in out),2)}

@app.get('/api/reports/profit-loss-v2')
def profit_loss_v2(date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    income=expense=0.0; by_account=[]
    for l,e in _journal_query(s,date_from,date_to).all():
        a=s.query(Account).filter_by(code=l.account_code).first()
        if not a: continue
        value=0.0
        if a.account_type=='income': value=l.credit-l.debit; income+=value
        elif a.account_type=='expense': value=l.debit-l.credit; expense+=value
        if value: by_account.append({'code':a.code,'name':a.name,'account_type':a.account_type,'amount':round(value,2)})
    return {'date_from':date_from,'date_to':date_to,'income':round(income,2),'expenses':round(expense,2),'net_profit':round(income-expense,2),'accounts':by_account}

@app.get('/api/reports/balance-sheet-v2')
def balance_sheet_v2(date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    groups={'asset':0.0,'liability':0.0,'equity':0.0,'income':0.0,'expense':0.0}
    for l,e in _journal_query(s,None,date_to).all():
        a=s.query(Account).filter_by(code=l.account_code).first()
        if not a or a.account_type not in groups: continue
        groups[a.account_type]+= (l.debit-l.credit) if a.account_type in ('asset','expense') else (l.credit-l.debit)
    profit=groups['income']-groups['expense']; equity=groups['equity']+profit
    return {'date_to':date_to,'assets':round(groups['asset'],2),'liabilities':round(groups['liability'],2),'equity':round(equity,2),'current_profit':round(profit,2),'difference':round(groups['asset']-(groups['liability']+equity),2),'balanced':abs(groups['asset']-(groups['liability']+equity))<0.01}

@app.get('/api/reports/customer-financial-reconciliation/{customer_id}')
def customer_financial_reconciliation(customer_id:int,date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    c=s.get(Customer,customer_id)
    if not c: raise HTTPException(404,'العميل غير موجود')
    invoices=s.query(Invoice).filter(Invoice.customer_id==customer_id,Invoice.posted==True)
    if date_from: invoices=invoices.filter(Invoice.date>=date_from)
    if date_to: invoices=invoices.filter(Invoice.date<=date_to)
    invs=invoices.order_by(Invoice.date,Invoice.id).all()
    receipts=_posted_receipts_for_customer(s,customer_id,date_from,date_to)
    invoice_total=round(sum(i.total for i in invs),2); paid_total=round(sum(v.amount for v in receipts),2)
    invoice_ids={i.id for i in invs}; receipt_rows=[]
    for v in receipts:
        receipt_rows.append({'voucher_id':v.id,'number':v.number,'date':v.date,'invoice_id':v.invoice_id,'amount':round(v.amount,2)})
    return {'customer_id':customer_id,'customer_name':c.name,'date_from':date_from,'date_to':date_to,'invoice_count':len(invs),'receipt_count':len(receipts),'total_invoices':invoice_total,'total_paid':paid_total,'outstanding':round(invoice_total-paid_total,2),'invoices':[{'id':i.id,'number':i.number,'date':i.date,'total':round(i.total,2)} for i in invs],'receipts':receipt_rows}


# ===== V2.9 general ledger, opening balances and annual closing =====
@app.get('/api/reports/general-ledger/{account_code}')
def general_ledger(account_code:str,date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    account=s.query(Account).filter_by(code=account_code).first()
    if not account: raise HTTPException(404,'الحساب غير موجود')
    q=s.query(JournalLine,JournalEntry).join(JournalEntry,JournalEntry.id==JournalLine.entry_id).filter(JournalLine.account_code==account_code)
    if date_to: q=q.filter(JournalEntry.date<=date_to)
    all_rows=q.order_by(JournalEntry.date,JournalEntry.id,JournalLine.id).all()
    opening=0.0
    if date_from:
        for l,e in all_rows:
            if e.date < date_from: opening += l.debit-l.credit
        all_rows=[(l,e) for l,e in all_rows if e.date>=date_from]
    rows=[]; balance=round(opening,2)
    for l,e in all_rows:
        balance=round(balance+l.debit-l.credit,2)
        rows.append({'date':e.date,'entry_id':e.id,'description':e.description,'debit':round(l.debit,2),'credit':round(l.credit,2),'balance':balance})
    return {'account':{'code':account.code,'name':account.name,'type':account.account_type},'date_from':date_from,'date_to':date_to,'opening_balance':round(opening,2),'rows':rows,'closing_balance':balance}

@app.get('/api/admin/opening-balances')
def list_opening_balances(s=Depends(db),u=Depends(manager)):
    return [{'id':x.id,'account_code':x.account_code,'date':x.date,'debit':x.debit,'credit':x.credit,'note':x.note,'posted':x.posted,'journal_entry_id':x.journal_entry_id} for x in s.query(OpeningBalance).order_by(OpeningBalance.id.desc()).all()]

@app.post('/api/admin/opening-balances')
def add_opening_balance(x:OpeningBalanceIn,s=Depends(db),u=Depends(manager)):
    if x.debit<0 or x.credit<0 or (x.debit>0 and x.credit>0) or x.debit+x.credit<=0: raise HTTPException(400,'الرصيد الافتتاحي غير صالح')
    if not s.query(Account).filter_by(code=x.account_code).first(): raise HTTPException(400,'الحساب غير موجود')
    ensure_open_period(s,x.date)
    z=OpeningBalance(**x.model_dump()); s.add(z); s.commit(); audit(s,u,'create','opening_balance',z.id)
    return {'id':z.id,'posted':False}

@app.post('/api/admin/opening-balances/{balance_id}/post')
def post_opening_balance(balance_id:int,s=Depends(db),u=Depends(manager)):
    z=s.get(OpeningBalance,balance_id)
    if not z: raise HTTPException(404,'الرصيد الافتتاحي غير موجود')
    if z.posted: raise HTTPException(409,'الرصيد الافتتاحي مرحّل بالفعل')
    code=mapped_code(s,'opening_equity','3000')
    amount=z.debit if z.debit else z.credit
    lines=[(z.account_code,z.debit,z.credit,z.note or 'رصيد افتتاحي'),(code,z.credit,z.debit,'مقابل الأرصدة الافتتاحية')]
    entry=post_journal(s,u,z.date,'ترحيل رصيد افتتاحي',lines); z.posted=True; z.journal_entry_id=entry.id; s.commit(); audit(s,u,'post','opening_balance',z.id)
    return {'id':z.id,'posted':True,'journal_entry_id':entry.id}

@app.get('/api/admin/fiscal-closes')
def fiscal_closes(s=Depends(db),u=Depends(manager)):
    return [{'id':x.id,'period_id':x.period_id,'journal_entry_id':x.journal_entry_id,'net_profit':x.net_profit,'closed_at':x.closed_at.isoformat(),'closed_by':x.closed_by} for x in s.query(FiscalClose).order_by(FiscalClose.id.desc()).all()]

@app.post('/api/admin/fiscal-periods/{period_id}/close-year')
def close_fiscal_year(period_id:int,s=Depends(db),u=Depends(manager)):
    p=s.get(FiscalPeriod,period_id)
    if not p: raise HTTPException(404,'الفترة غير موجودة')
    if p.closed or s.query(FiscalClose).filter_by(period_id=period_id).first(): raise HTTPException(409,'الفترة مغلقة بالفعل')
    overlaps=s.query(FiscalPeriod).filter(FiscalPeriod.id!=p.id,FiscalPeriod.start_date<=p.end_date,FiscalPeriod.end_date>=p.start_date).first()
    if overlaps: raise HTTPException(409,'الفترة تتداخل مع فترة محاسبية أخرى')
    income=expense=0.0; lines=[]
    for l,e in _journal_query(s,p.start_date,p.end_date).all():
        a=s.query(Account).filter_by(code=l.account_code).first()
        if not a: continue
        if a.account_type=='income': income += l.credit-l.debit
        elif a.account_type=='expense': expense += l.debit-l.credit
    profit=round(income-expense,2)
    if abs(profit)>0.005:
        retained=mapped_code(s,'retained_earnings','3000')
        if profit>0: lines=[(mapped_code(s,'closing_income','4100'),profit,0,'إقفال الإيرادات'),(retained,0,profit,'صافي الربح المرحّل')]
        else:
            loss=abs(profit); lines=[(retained,loss,0,'صافي الخسارة المرحّلة'),(mapped_code(s,'closing_expense','5100'),0,loss,'إقفال المصروفات')]
        entry=post_journal(s,u,p.end_date,'إقفال السنة المالية '+p.name,lines)
    else:
        entry=None
    p.closed=True; s.add(FiscalClose(period_id=p.id,journal_entry_id=entry.id if entry else None,net_profit=profit,closed_by=u.id)); s.commit(); audit(s,u,'close_year','fiscal_period',p.id)
    return {'period_id':p.id,'closed':True,'net_profit':profit,'journal_entry_id':entry.id if entry else None}

@app.get('/api/reports/trial-balance')
def trial_balance(s=Depends(db),u=Depends(current_user)):
    rows={}
    for a in s.query(Account).all(): rows[a.code]={'code':a.code,'name':a.name,'debit':0.0,'credit':0.0}
    for l in s.query(JournalLine).all():
        rows.setdefault(l.account_code,{'code':l.account_code,'name':'غير معرف','debit':0.0,'credit':0.0})
        rows[l.account_code]['debit']+=l.debit; rows[l.account_code]['credit']+=l.credit
    out=[]
    for x in rows.values():
        x['debit']=round(x['debit'],2); x['credit']=round(x['credit'],2); x['balance']=round(x['debit']-x['credit'],2); out.append(x)
    return {'rows':out,'total_debit':round(sum(x['debit'] for x in out),2),'total_credit':round(sum(x['credit'] for x in out),2)}

@app.get('/api/reports/balance-sheet')
def balance_sheet(s=Depends(db),u=Depends(current_user)):
    groups={'asset':0.0,'liability':0.0,'equity':0.0,'income':0.0,'expense':0.0}
    for l in s.query(JournalLine).all():
        a=s.query(Account).filter_by(code=l.account_code).first()
        if not a: continue
        if a.account_type in ('asset','expense'): groups[a.account_type]+=l.debit-l.credit
        else: groups[a.account_type]+=l.credit-l.debit
    current_profit=groups['income']-groups['expense']
    equity=groups['equity']+current_profit
    return {'assets':round(groups['asset'],2),'liabilities':round(groups['liability'],2),'equity':round(equity,2),'current_profit':round(current_profit,2),'balanced':round(groups['asset']-(groups['liability']+equity),2)==0}

@app.get('/api/reports/account-statement/{account_code}')
def account_statement(account_code:str, date_from:str|None=None, date_to:str|None=None, s=Depends(db),u=Depends(current_user)):
    account=s.query(Account).filter_by(code=account_code).first()
    q=s.query(JournalLine,JournalEntry).join(JournalEntry,JournalEntry.id==JournalLine.entry_id).filter(JournalLine.account_code==account_code)
    if date_from: q=q.filter(JournalEntry.date>=date_from)
    if date_to: q=q.filter(JournalEntry.date<=date_to)
    rows=[]; balance=0.0
    for l,e in q.order_by(JournalEntry.date,JournalEntry.id,JournalLine.id).all():
        balance=round(balance+l.debit-l.credit,2)
        rows.append({'date':e.date,'description':e.description,'debit':l.debit,'credit':l.credit,'balance':balance,'entry_id':e.id})
    return {'account':{'code':account_code,'name':account.name if account else 'غير معرف'},'date_from':date_from,'date_to':date_to,'opening_balance':0.0,'rows':rows,'closing_balance':balance}

def _pdf_title(canvas, doc):
    canvas.saveState(); canvas.setFont('Helvetica',9); canvas.drawString(40, A4[1]-35, 'ثابت أنعم للتخليص الجمركي'); canvas.drawRightString(A4[0]-40,A4[1]-35,'ERP V2.0'); canvas.restoreState()

def _make_pdf(title, headers, rows, filename):
    path=pathlib.Path('/tmp')/filename
    doc=SimpleDocTemplate(str(path),pagesize=A4,rightMargin=30,leftMargin=30,topMargin=55,bottomMargin=35)
    styles=getSampleStyleSheet(); story=[Paragraph(title,styles['Title']),Spacer(1,12)]
    data=[headers]+rows
    t=Table(data,repeatRows=1); t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),0.5,colors.grey),('BACKGROUND',(0,0),(-1,0),colors.lightgrey),('FONTSIZE',(0,0),(-1,-1),8),('VALIGN',(0,0),(-1,-1),'MIDDLE')]))
    story.append(t); doc.build(story,onFirstPage=_pdf_title,onLaterPages=_pdf_title); return path

from fastapi.responses import FileResponse, Response
@app.get('/api/reports/trial-balance.pdf')
def trial_balance_pdf(s=Depends(db),u=Depends(current_user)):
    data=trial_balance(s,u)['rows']; rows=[[x['code'],x['name'],x['debit'],x['credit'],x['balance']] for x in data]
    path=_make_pdf('ميزان المراجعة',['الحساب','اسم الحساب','مدين','دائن','الرصيد'],rows,'trial_balance.pdf')
    return FileResponse(path,media_type='application/pdf',filename='trial_balance.pdf')

@app.get('/api/reports/profit-loss.pdf')
def profit_loss_pdf(s=Depends(db),u=Depends(current_user)):
    x=profit_loss(s,u); rows=[['الإيرادات',x['income']],['المصروفات',x['expenses']],['صافي الربح',x['net_profit']]]
    path=_make_pdf('الأرباح والخسائر',['البند','القيمة'],rows,'profit_loss.pdf')
    return FileResponse(path,media_type='application/pdf',filename='profit_loss.pdf')

@app.get('/api/reports/profit-loss')
def profit_loss(s=Depends(db),u=Depends(current_user)):
    income=expense=0.0
    for l in s.query(JournalLine).all():
        if l.account_code.startswith('4'): income += l.credit-l.debit
        if l.account_code.startswith('5') or l.account_code.startswith('6'): expense += l.debit-l.credit
    return {'income':round(income,2),'expenses':round(expense,2),'net_profit':round(income-expense,2)}

@app.get('/api/shipments/{shipment_id}/profile')
def get_shipment_profile(shipment_id:int,s=Depends(db),u=Depends(current_user)):
    if not s.get(Shipment,shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    p=s.query(ShipmentProfile).filter_by(shipment_id=shipment_id).first()
    return p.__dict__|{} if p else {'shipment_id':shipment_id}

@app.put('/api/shipments/{shipment_id}/profile')
def set_shipment_profile(shipment_id:int,x:ShipmentProfileIn,s=Depends(db),u=Depends(current_user)):
    z=s.get(Shipment,shipment_id)
    if not z: raise HTTPException(404,'الشحنة غير موجودة')
    p=s.query(ShipmentProfile).filter_by(shipment_id=shipment_id).first() or ShipmentProfile(shipment_id=shipment_id)
    for k,v in x.model_dump().items(): setattr(p,k,v)
    if x.importer_name: z.importer_name=x.importer_name
    s.add(p); s.commit(); audit(s,u,'update','shipment_profile',shipment_id)
    return {'shipment_id':shipment_id,**x.model_dump()}

@app.get('/api/shipments/{shipment_id}/checklist')
def shipment_checklist(shipment_id:int,s=Depends(db),u=Depends(current_user)):
    if not s.get(Shipment,shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    q=s.query(ShipmentChecklist).filter_by(shipment_id=shipment_id).order_by(ShipmentChecklist.id).all()
    if not q:
        defaults=['الفاتورة التجارية','قائمة التعبئة Packing List','بوليصة الشحن','شهادة المنشأ','البيان الجمركي']
        for d in defaults: s.add(ShipmentChecklist(shipment_id=shipment_id,doc_type=d,required=True,received=False))
        s.commit(); q=s.query(ShipmentChecklist).filter_by(shipment_id=shipment_id).all()
    return [{'id':x.id,'doc_type':x.doc_type,'required':x.required,'received':x.received,'notes':x.notes} for x in q]

@app.post('/api/shipments/{shipment_id}/checklist')
def add_checklist(shipment_id:int,x:ChecklistIn,s=Depends(db),u=Depends(current_user)):
    if not s.get(Shipment,shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    z=ShipmentChecklist(shipment_id=shipment_id,**x.model_dump()); s.add(z); s.commit(); audit(s,u,'create','checklist',z.id)
    return {'id':z.id,**x.model_dump()}

@app.patch('/api/shipments/checklist/{check_id}')
def update_checklist(check_id:int,x:ChecklistIn,s=Depends(db),u=Depends(current_user)):
    z=s.get(ShipmentChecklist,check_id)
    if not z: raise HTTPException(404,'البند غير موجود')
    for k,v in x.model_dump().items(): setattr(z,k,v)
    s.commit(); audit(s,u,'update','checklist',z.id); return {'id':z.id,**x.model_dump()}

def norm(v):
    return ''.join(str(v or '').lower().replace(' ','').replace('-','').replace('_','').replace('/',''))
def match_num(a,b,tol=0.01):
    return abs(float(a or 0)-float(b or 0)) <= max(tol,abs(float(a or 0))*tol)

@app.get('/api/shipments/{shipment_id}/document-items')
def get_document_items(shipment_id:int,source:str|None=None,s=Depends(db),u=Depends(current_user)):
    q=s.query(DocumentItem).filter_by(shipment_id=shipment_id)
    if source: q=q.filter_by(source=source)
    return [x.__dict__|{} for x in q.order_by(DocumentItem.source,DocumentItem.line_no,DocumentItem.id).all()]

@app.post('/api/shipments/{shipment_id}/document-items')
def add_document_item(shipment_id:int,x:DocumentItemIn,s=Depends(db),u=Depends(current_user)):
    if not s.get(Shipment,shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    if x.source not in {'invoice','packing_list','bill_of_lading','certificate_of_origin','customs_declaration'}:
        raise HTTPException(400,'مصدر المستند غير مدعوم')
    z=DocumentItem(shipment_id=shipment_id,**x.model_dump()); s.add(z); s.commit(); audit(s,u,'create','document_item',z.id)
    return {'id':z.id,**x.model_dump()}

@app.delete('/api/shipments/document-items/{item_id}')
def delete_document_item(item_id:int,s=Depends(db),u=Depends(current_user)):
    z=s.get(DocumentItem,item_id)
    if not z: raise HTTPException(404,'الصنف غير موجود')
    s.delete(z); s.commit(); audit(s,u,'delete','document_item',item_id); return {'deleted':True,'id':item_id}

@app.post('/api/shipments/{shipment_id}/match-stored')
def match_stored(shipment_id:int,x:MatchStoredRequest,s=Depends(db),u=Depends(current_user)):
    if not s.get(Shipment,shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    q=s.query(DocumentItem).filter_by(shipment_id=shipment_id)
    if x.sources: q=q.filter(DocumentItem.source.in_(x.sources))
    rows=q.all()
    if len(rows)<2: raise HTTPException(400,'أدخل بيانات مستندين على الأقل')
    data=[MatchItemIn(source=r.source,key=r.barcode or r.description,description=r.description,barcode=r.barcode,qty=r.qty,cartons=r.cartons,net_weight=r.net_weight,unit_price=r.unit_price,customs_value=r.customs_value) for r in rows]
    return smart_match(shipment_id,MatchRequest(items=data),s,u)

@app.post('/api/shipments/{shipment_id}/match')
def smart_match(shipment_id:int,x:MatchRequest,s=Depends(db),u=Depends(current_user)):
    if not s.get(Shipment,shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    if not x.items: raise HTTPException(400,'أدخل أصناف المستندات للمطابقة')
    grouped={}
    for it in x.items:
        key=norm(it.barcode) or norm(it.key) or norm(it.description)
        grouped.setdefault(key,[]).append(it)
    results=[]; scores=[]
    for key,arr in grouped.items():
        by={}
        for it in arr: by.setdefault(it.source,[]).append(it)
        sources=list(by)
        if len(sources)<2:
            results.append((key,arr[0].description,'غير مكتمل',{'sources':sources})); continue
        base=by[sources[0]][0]
        diffs={}; ok=True
        for src in sources[1:]:
            other=by[src][0]
            fields=[('qty',base.qty,other.qty),('cartons',base.cartons,other.cartons),('net_weight',base.net_weight,other.net_weight),('unit_price',base.unit_price,other.unit_price),('customs_value',base.customs_value,other.customs_value)]
            for name,a,b in fields:
                if (a or b) and not match_num(a,b): diffs[f'{src}.{name}']=(a,b); ok=False
            if norm(base.description) and norm(other.description) and norm(base.description)!=norm(other.description): diffs[f'{src}.description']=(base.description,other.description); ok=False
        results.append((key,base.description,'مطابق' if ok else 'يوجد اختلاف',diffs)); scores.append(100 if ok else max(0,100-15*len(diffs)))
    score=round(sum(scores)/len(scores),2) if scores else 0
    status='مطابق' if score>=95 else ('مطابقة جزئية' if score>=70 else 'يحتاج مراجعة')
    run=MatchRun(shipment_id=shipment_id,created_by=u.id,score=score,status=status,summary=f'تمت مطابقة {len(results)} مجموعة')
    s.add(run); s.flush()
    import json
    for key,desc,st,diff in results: s.add(MatchResult(run_id=run.id,item_key=key,source_a='multi',source_b='multi',description=desc,status=st,differences=json.dumps(diff,ensure_ascii=False)))
    s.commit(); audit(s,u,'create','match_run',run.id)
    return {'run_id':run.id,'score':score,'status':status,'results':[{'key':k,'description':d,'status':st,'differences':df} for k,d,st,df in results]}

@app.get('/api/shipments/{shipment_id}/matches')
def shipment_matches(shipment_id:int,s=Depends(db),u=Depends(current_user)):
    runs=s.query(MatchRun).filter_by(shipment_id=shipment_id).order_by(MatchRun.id.desc()).all()
    return [{'id':r.id,'created_at':r.created_at.isoformat(),'score':r.score,'status':r.status,'summary':r.summary} for r in runs]

@app.get('/api/shipments/{shipment_id}/readiness')
def shipment_readiness(shipment_id:int,s=Depends(db),u=Depends(current_user)):
    if not s.get(Shipment,shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    q=s.query(ShipmentChecklist).filter_by(shipment_id=shipment_id,required=True).all()
    received=sum(1 for x in q if x.received); total=len(q)
    return {'shipment_id':shipment_id,'required':total,'received':received,'missing':total-received,'ready':total>0 and received==total,'percent':round(received*100/total,2) if total else 0}


def get_mapping(s,key,default=''):
    x=s.get(AccountMapping,key)
    return x.account_code if x else default

def has_permission(s,u,module,action):
    if u.role=='manager': return True
    x=s.query(Permission).filter(Permission.role==u.role,Permission.module==module,Permission.action==action).first()
    return True if x is None else x.allowed

def require_permission(module,action):
    def dep(u=Depends(current_user),s=Depends(db)):
        if not has_permission(s,u,module,action): raise HTTPException(403,'لا تملك هذه الصلاحية')
        return u
    return dep

@app.get('/api/admin/custom-values')
def list_custom_values(entity:str,entity_id:int,u=Depends(manager),s:Session=Depends(db)):
    return [{'id':x.id,'entity':x.entity,'entity_id':x.entity_id,'field_key':x.field_key,'value':x.value} for x in s.query(CustomFieldValue).filter_by(entity=entity,entity_id=entity_id).all()]

@app.put('/api/admin/custom-values')
def set_custom_value(v:CustomValueIn,u=Depends(manager),s:Session=Depends(db)):
    f=s.query(CustomField).filter_by(entity=v.entity,key=v.field_key).first()
    if not f: raise HTTPException(404,'الحقل المخصص غير موجود')
    x=s.query(CustomFieldValue).filter_by(entity=v.entity,entity_id=v.entity_id,field_key=v.field_key).first()
    if not x: x=CustomFieldValue(entity=v.entity,entity_id=v.entity_id,field_key=v.field_key); s.add(x)
    x.value=str(v.value); s.commit(); audit(s,u,'set_custom_value',v.entity,v.entity_id)
    return {'ok':True,'value':x.value}

@app.get('/api/admin/workflows')
def workflows(u=Depends(manager),s:Session=Depends(db)):
    import json
    return [{'id':x.id,'entity':x.entity,'name':x.name,'states':json.loads(x.states_json),'active':x.active} for x in s.query(WorkflowDefinition).all()]

@app.post('/api/admin/workflows')
def add_workflow(v:WorkflowIn,u=Depends(manager),s:Session=Depends(db)):
    import json
    if len(v.states)<2: raise HTTPException(400,'يجب أن تحتوي دورة العمل على حالتين على الأقل')
    x=WorkflowDefinition(entity=v.entity,name=v.name,states_json=json.dumps(v.states,ensure_ascii=False)); s.add(x); s.commit(); audit(s,u,'create','workflow',x.id)
    return {'id':x.id,'entity':x.entity,'name':x.name,'states':v.states}

@app.get('/api/workflows/{entity}/{entity_id}')
def workflow_state(entity:str,entity_id:int,u=Depends(current_user),s:Session=Depends(db)):
    import json
    wf=s.query(WorkflowDefinition).filter_by(entity=entity,active=True).first()
    if not wf: return {'configured':False,'state':None,'states':[]}
    r=s.query(WorkflowRecord).filter_by(workflow_id=wf.id,entity_id=entity_id).first()
    states=json.loads(wf.states_json)
    return {'configured':True,'workflow_id':wf.id,'state':r.state if r else states[0],'states':states}

@app.post('/api/workflows/transition')
def transition(v:TransitionIn,u=Depends(current_user),s:Session=Depends(db)):
    import json
    wf=s.get(WorkflowDefinition,v.workflow_id)
    if not wf or not wf.active: raise HTTPException(404,'دورة العمل غير موجودة')
    states=json.loads(wf.states_json)
    if v.state not in states: raise HTTPException(400,'الحالة غير معرفة في دورة العمل')
    r=s.query(WorkflowRecord).filter_by(workflow_id=wf.id,entity_id=v.entity_id).first()
    if not r: r=WorkflowRecord(workflow_id=wf.id,entity_id=v.entity_id,state=v.state,updated_by=u.id); s.add(r)
    else: r.state=v.state; r.updated_by=u.id; r.updated_at=datetime.now(timezone.utc)
    s.commit(); audit(s,u,'transition',wf.entity,v.entity_id)
    return {'ok':True,'state':r.state}

@app.get('/api/admin/permissions')
def permissions(role:str|None=None,u=Depends(manager),s:Session=Depends(db)):
    q=s.query(Permission)
    if role: q=q.filter(Permission.role==role)
    return [{'id':x.id,'role':x.role,'module':x.module,'action':x.action,'allowed':x.allowed} for x in q.order_by(Permission.role,Permission.module,Permission.action).all()]

@app.put('/api/admin/permissions')
def set_permission(v:PermissionIn,u=Depends(manager),s:Session=Depends(db)):
    if v.role=='manager': raise HTTPException(400,'صلاحيات المدير الأساسية لا تُلغى من هذه الواجهة')
    x=s.query(Permission).filter_by(role=v.role,module=v.module,action=v.action).first()
    if not x: x=Permission(role=v.role,module=v.module,action=v.action); s.add(x)
    x.allowed=v.allowed; s.commit(); audit(s,u,'permission','role',v.role); return {'ok':True,'role':v.role,'module':v.module,'action':v.action,'allowed':v.allowed}

@app.put('/api/admin/permissions/bulk')
def set_permissions_bulk(v:PermissionBulkIn,u=Depends(manager),s:Session=Depends(db)):
    if v.role=='manager': raise HTTPException(400,'صلاحيات المدير الأساسية لا تُلغى من هذه الواجهة')
    for item in v.permissions:
        if item.role!=v.role: raise HTTPException(400,'كل الصلاحيات يجب أن تخص الدور المحدد')
        x=s.query(Permission).filter_by(role=v.role,module=item.module,action=item.action).first()
        if not x: x=Permission(role=v.role,module=item.module,action=item.action); s.add(x)
        x.allowed=item.allowed
    s.commit(); audit(s,u,'permission_bulk','role',v.role)
    return {'ok':True,'role':v.role,'count':len(v.permissions)}

@app.get('/api/admin/roles')
def roles(u=Depends(manager),s:Session=Depends(db)):
    roles=sorted({x.role for x in s.query(User).all()} | {x.role for x in s.query(Permission).all()} | {'manager','user'})
    return [{'role':r,'users':s.query(User).filter_by(role=r).count(),'permissions':s.query(Permission).filter_by(role=r).count()} for r in roles]

@app.get('/api/admin/reports')
def saved_reports(u=Depends(manager),s:Session=Depends(db)):
    import json
    return [{'id':x.id,'name':x.name,'source':x.source,'columns':json.loads(x.columns_json),'active':x.active} for x in s.query(ReportDefinition).all()]

@app.post('/api/admin/reports')
def add_report(v:ReportIn,u=Depends(manager),s:Session=Depends(db)):
    import json
    allowed={'accounts','customers','suppliers','shipments','invoices','purchases'}
    if v.source not in allowed: raise HTTPException(400,'مصدر التقرير غير مدعوم')
    x=ReportDefinition(name=v.name,source=v.source,columns_json=json.dumps(v.columns,ensure_ascii=False)); s.add(x); s.commit(); audit(s,u,'create','report',x.id); return {'id':x.id}

@app.get('/api/reports/custom/{report_id}')
def run_saved_report(report_id:int,u=Depends(current_user),s:Session=Depends(db)):
    import json
    x=s.get(ReportDefinition,report_id)
    if not x or not x.active: raise HTTPException(404,'التقرير غير موجود')
    models={'accounts':Account,'customers':Customer,'suppliers':Supplier,'shipments':Shipment,'invoices':Invoice,'purchases':Purchase}
    model=models[x.source]; rows=s.query(model).all(); cols=json.loads(x.columns_json)
    out=[]
    for r in rows:
        d={c:getattr(r,c,None) for c in cols if hasattr(r,c)}
        out.append(d)
    return {'name':x.name,'source':x.source,'columns':cols,'rows':out,'count':len(out)}

@app.post('/api/auth/change-password')
def change_password(x:PasswordChange,s=Depends(db),u=Depends(current_user)):
    if not check_pw(x.old_password,u.password_hash): raise HTTPException(400,'كلمة المرور الحالية غير صحيحة')
    u.password_hash=hash_pw(x.new_password); s.commit(); audit(s,u,'update','password',u.id); return {'status':'changed'}

@app.patch('/api/users/{user_id}')
def patch_user(user_id:int,x:UserPatch,s=Depends(db),u=Depends(manager)):
    z=s.get(User,user_id)
    if not z: raise HTTPException(404,'المستخدم غير موجود')
    if x.name is not None: z.name=x.name
    if x.role is not None: z.role=x.role
    if x.active is not None: z.active=x.active
    if x.password is not None: z.password_hash=hash_pw(x.password)
    s.commit(); audit(s,u,'update','user',z.id); return {'id':z.id,'username':z.username,'name':z.name,'role':z.role,'active':z.active}


# ===== V1.0 Integrated Customs + Accounting + Approval layer =====
class ShipmentCharge(Base):
    __tablename__='shipment_charges'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    shipment_id:Mapped[int]=mapped_column(ForeignKey('shipments.id'),index=True)
    charge_type:Mapped[str]=mapped_column(String(80),default='خدمة')
    description:Mapped[str]=mapped_column(String(250),default='')
    amount:Mapped[float]=mapped_column(Float,default=0)
    currency:Mapped[str]=mapped_column(String(20),default='YER')
    account_code:Mapped[str]=mapped_column(String(50),default='5100')
    approved:Mapped[bool]=mapped_column(Boolean,default=False)
    created_by:Mapped[int]=mapped_column(Integer)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))

class ApprovalRequest(Base):
    __tablename__='approval_requests'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    entity:Mapped[str]=mapped_column(String(80),index=True)
    entity_id:Mapped[int]=mapped_column(Integer,index=True)
    action:Mapped[str]=mapped_column(String(80))
    reason:Mapped[str]=mapped_column(Text,default='')
    status:Mapped[str]=mapped_column(String(30),default='معلق')
    requested_by:Mapped[int]=mapped_column(Integer)
    approved_by:Mapped[int|None]=mapped_column(Integer,nullable=True)
    created_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))
    decided_at:Mapped[datetime|None]=mapped_column(DateTime,nullable=True)

class ShipmentFinancialLink(Base):
    __tablename__='shipment_financial_links'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    shipment_id:Mapped[int]=mapped_column(ForeignKey('shipments.id'),unique=True,index=True)
    invoice_id:Mapped[int|None]=mapped_column(ForeignKey('invoices.id'),nullable=True)
    total_charges:Mapped[float]=mapped_column(Float,default=0)
    total_revenue:Mapped[float]=mapped_column(Float,default=0)
    margin:Mapped[float]=mapped_column(Float,default=0)

Base.metadata.create_all(engine)

class ChargeIn(BaseModel):
    charge_type:str='خدمة'
    description:str=''
    amount:float
    currency:str='YER'
    account_code:str='5100'

class ApprovalIn(BaseModel):
    entity:str
    entity_id:int
    action:str
    reason:str=''

class ApprovalDecisionIn(BaseModel):
    decision:str
    notes:str=''

class ShipmentInvoiceIn(BaseModel):
    number:str
    date:str
    description:str='خدمات تخليص جمركي'
    amount:float|None=None
    customer_id:int|None=None


def create_approval(s,u,entity,entity_id,action,reason=''):
    z=ApprovalRequest(entity=entity,entity_id=entity_id,action=action,reason=reason,requested_by=u.id,status='معلق')
    s.add(z); s.commit(); audit(s,u,'request_approval',entity,entity_id)
    return z

@app.get('/api/shipments/{shipment_id}/charges')
def shipment_charges(shipment_id:int,s=Depends(db),u=Depends(current_user)):
    rows=s.query(ShipmentCharge).filter_by(shipment_id=shipment_id).order_by(ShipmentCharge.id.desc()).all()
    total=round(sum(x.amount for x in rows),2)
    return {'shipment_id':shipment_id,'total':total,'rows':[{'id':x.id,'charge_type':x.charge_type,'description':x.description,'amount':x.amount,'currency':x.currency,'account_code':x.account_code,'approved':x.approved} for x in rows]}

@app.post('/api/shipments/{shipment_id}/charges')
def add_shipment_charge(shipment_id:int,x:ChargeIn,s=Depends(db),u=Depends(current_user)):
    if not s.get(Shipment,shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    if x.amount<=0: raise HTTPException(400,'قيمة التكلفة يجب أن تكون أكبر من صفر')
    z=ShipmentCharge(shipment_id=shipment_id,**x.model_dump(),created_by=u.id,approved=False)
    s.add(z); s.commit(); audit(s,u,'create','shipment_charge',z.id)
    create_approval(s,u,'shipment_charge',z.id,'اعتماد تكلفة','تكلفة مرتبطة بالشحنة')
    return {'id':z.id,'status':'معلق للموافقة'}

@app.get('/api/approvals')
def approvals(status:str|None=None,s=Depends(db),u=Depends(manager)):
    q=s.query(ApprovalRequest).order_by(ApprovalRequest.id.desc())
    if status: q=q.filter_by(status=status)
    return [{'id':x.id,'entity':x.entity,'entity_id':x.entity_id,'action':x.action,'reason':x.reason,'status':x.status,'requested_by':x.requested_by,'approved_by':x.approved_by,'created_at':x.created_at.isoformat(),'decided_at':x.decided_at.isoformat() if x.decided_at else None} for x in q.limit(500).all()]

@app.post('/api/approvals/{approval_id}/decide')
def decide_approval(approval_id:int,x:ApprovalDecisionIn,s=Depends(db),u=Depends(manager)):
    if x.decision not in {'موافقة','رفض'}: raise HTTPException(400,'القرار يجب أن يكون موافقة أو رفض')
    z=s.get(ApprovalRequest,approval_id)
    if not z: raise HTTPException(404,'طلب الموافقة غير موجود')
    if z.status!='معلق': raise HTTPException(409,'تم اتخاذ قرار لهذا الطلب مسبقًا')
    z.status=x.decision; z.approved_by=u.id; z.decided_at=datetime.now(timezone.utc)
    if z.entity=='shipment_charge':
        charge=s.get(ShipmentCharge,z.entity_id)
        if charge: charge.approved=(x.decision=='موافقة')
    s.commit(); audit(s,u,'approval_decision',z.entity,z.entity_id)
    return {'ok':True,'status':z.status}

@app.post('/api/shipments/{shipment_id}/request-approval')
def request_shipment_approval(shipment_id:int,x:ApprovalIn,s=Depends(db),u=Depends(current_user)):
    if not s.get(Shipment,shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    if x.entity!='shipment' or x.entity_id!=shipment_id: raise HTTPException(400,'بيانات طلب الموافقة غير متطابقة')
    z=create_approval(s,u,x.entity,x.entity_id,x.action,x.reason)
    return {'id':z.id,'status':z.status}

@app.post('/api/shipments/{shipment_id}/generate-invoice')
def generate_shipment_invoice(shipment_id:int,x:ShipmentInvoiceIn,s=Depends(db),u=Depends(current_user)):
    sh=s.get(Shipment,shipment_id)
    if not sh: raise HTTPException(404,'الشحنة غير موجودة')
    amount=x.amount
    if amount is None:
        amount=round(sum(c.amount for c in s.query(ShipmentCharge).filter_by(shipment_id=shipment_id,approved=True).all()),2)
    if amount<=0: raise HTTPException(400,'لا توجد قيمة فوترة معتمدة')
    if s.query(Invoice).filter_by(number=x.number).first(): raise HTTPException(409,'رقم الفاتورة موجود')
    inv=Invoice(number=x.number,date=x.date,customer_id=x.customer_id,description=x.description,total=amount,paid=0,status='غير مسددة',posted=False)
    s.add(inv); s.flush(); s.add(InvoiceLine(invoice_id=inv.id,description=x.description,qty=1,unit_price=amount,total=amount));
    link=s.query(ShipmentFinancialLink).filter_by(shipment_id=shipment_id).first()
    if not link: link=ShipmentFinancialLink(shipment_id=shipment_id); s.add(link)
    link.invoice_id=inv.id; link.total_revenue=amount
    s.commit(); audit(s,u,'create','shipment_invoice',inv.id)
    return {'invoice_id':inv.id,'number':inv.number,'amount':amount,'posted':False,'note':'الفاتورة تحتاج ترحيلًا محاسبيًا منفصلًا'}

@app.get('/api/shipments/{shipment_id}/financial-summary')
def shipment_financial_summary(shipment_id:int,s=Depends(db),u=Depends(current_user)):
    sh=s.get(Shipment,shipment_id)
    if not sh: raise HTTPException(404,'الشحنة غير موجودة')
    charges=s.query(ShipmentCharge).filter_by(shipment_id=shipment_id,approved=True).all()
    total_cost=round(sum(x.amount for x in charges),2)
    link=s.query(ShipmentFinancialLink).filter_by(shipment_id=shipment_id).first()
    revenue=round(link.total_revenue if link else 0,2)
    return {'shipment_id':shipment_id,'shipment_status':sh.status,'approved_costs':total_cost,'revenue':revenue,'margin':round(revenue-total_cost,2),'invoice_id':link.invoice_id if link else None}

@app.get('/api/work-center')
def work_center(s=Depends(db),u=Depends(current_user)):
    pending_approvals=s.query(ApprovalRequest).filter_by(status='معلق').count()
    pending_docs=0
    for sh in s.query(Shipment).all():
        checks=s.query(ShipmentChecklist).filter_by(shipment_id=sh.id,required=True,received=False).count()
        pending_docs+=checks
    open_invoices=s.query(Invoice).filter(Invoice.status!='مسددة').count()
    return {'version':APP_VERSION,'pending_approvals':pending_approvals,'pending_required_documents':pending_docs,'open_invoices':open_invoices,'shipments':s.query(Shipment).count(),'customers':s.query(Customer).count(),'suppliers':s.query(Supplier).count()}


# V1.2: spreadsheet/CSV import, normalization and reconciliation utilities
SOURCE_ALIASES={
    'invoice':'invoice','فاتورة':'invoice','الفاتورة':'invoice','commercial_invoice':'invoice',
    'packing_list':'packing_list','packing list':'packing_list','قائمة التعبئة':'packing_list','التعبئة':'packing_list',
    'bill_of_lading':'bill_of_lading','bol':'bill_of_lading','بوليصة الشحن':'bill_of_lading','بوليصة':'bill_of_lading',
    'certificate_of_origin':'certificate_of_origin','coo':'certificate_of_origin','شهادة المنشأ':'certificate_of_origin','المنشأ':'certificate_of_origin',
    'customs_declaration':'customs_declaration','declaration':'customs_declaration','البيان':'customs_declaration','بيان جمركي':'customs_declaration'
}

def norm_text(v):
    v=str(v or '').strip().lower()
    v=unicodedata.normalize('NFKC',v)
    v=''.join(c for c in v if unicodedata.category(c)!='Mn')
    v=v.translate(str.maketrans({'أ':'ا','إ':'ا','آ':'ا','ى':'ي','ة':'ه','ؤ':'و','ئ':'ي'}))
    v=re.sub(r'[\s\-_/\\.,;:()\[\]{}]+','',v)
    return v

def canonical_source(v):
    k=norm_text(v)
    return SOURCE_ALIASES.get(v.strip().lower(), SOURCE_ALIASES.get(k,k))

def csv_float(v):
    try: return float(str(v or '0').replace(',','').strip() or 0)
    except: return 0.0

def row_value(row,*names):
    lowered={norm_text(k):v for k,v in row.items() if k is not None}
    for n in names:
        if norm_text(n) in lowered: return lowered[norm_text(n)]
    return ''

@app.post('/api/shipments/{shipment_id}/import-csv')
async def import_document_csv(shipment_id:int, source:str, file:UploadFile=File(...), replace_existing:bool=False, s=Depends(db), u=Depends(current_user)):
    if not s.get(Shipment,shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    src=canonical_source(source)
    if src not in {'invoice','packing_list','bill_of_lading','certificate_of_origin','customs_declaration'}:
        raise HTTPException(400,'نوع المستند غير مدعوم')
    raw=await file.read()
    text=raw.decode('utf-8-sig',errors='replace')
    try: rows=list(csv.DictReader(io.StringIO(text)))
    except Exception as e: raise HTTPException(400,f'تعذر قراءة CSV: {e}')
    if not rows: raise HTTPException(400,'الملف فارغ أو لا يحتوي صفوفًا')
    if replace_existing: s.query(DocumentItem).filter_by(shipment_id=shipment_id,source=src).delete(synchronize_session=False)
    added=0
    for idx,row in enumerate(rows,1):
        desc=row_value(row,'description','item','item_description','الصنف','الوصف')
        barcode=row_value(row,'barcode','sku','hs_code','باركود','الباركود')
        qty=csv_float(row_value(row,'qty','quantity','الكمية'))
        cartons=csv_float(row_value(row,'cartons','packages','carton','الكراتين','عدد الكراتين'))
        weight=csv_float(row_value(row,'net_weight','weight','net','الوزن','الوزن الصافي'))
        price=csv_float(row_value(row,'unit_price','price','unit_cost','سعر الوحدة','السعر'))
        customs=csv_float(row_value(row,'customs_value','customs','customs_amount','القيمة الجمركية'))
        currency=row_value(row,'currency','العملة') or 'USD'
        if not (desc or barcode): continue
        s.add(DocumentItem(shipment_id=shipment_id,source=src,line_no=idx,description=str(desc),barcode=str(barcode),qty=qty,cartons=cartons,net_weight=weight,unit_price=price,customs_value=customs,currency=str(currency)))
        added+=1
    s.commit(); audit(s,u,'import_csv','document_items',shipment_id)
    return {'shipment_id':shipment_id,'source':src,'file_name':file.filename or '','rows_read':len(rows),'rows_added':added,'replaced':replace_existing}

@app.get('/api/shipments/{shipment_id}/reconciliation')
def reconciliation(shipment_id:int,s=Depends(db),u=Depends(current_user)):
    if not s.get(Shipment,shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    rows=s.query(DocumentItem).filter_by(shipment_id=shipment_id).all()
    groups={}
    for r in rows:
        key=norm_text(r.barcode) or norm_text(r.description) or f'line-{r.id}'
        g=groups.setdefault(key,{'key':key,'description':r.description,'barcode':r.barcode,'sources':{},'differences':[]})
        g['sources'][r.source]={'line_no':r.line_no,'description':r.description,'barcode':r.barcode,'qty':r.qty,'cartons':r.cartons,'net_weight':r.net_weight,'unit_price':r.unit_price,'customs_value':r.customs_value,'currency':r.currency}
    source_list=['invoice','packing_list','bill_of_lading','certificate_of_origin','customs_declaration']
    for g in groups.values():
        srcs=g['sources']
        present=[x for x in source_list if x in srcs]
        if len(present)<2:
            g['status']='ناقص مستندات'; continue
        base=srcs[present[0]]; dif=[]
        for src in present[1:]:
            cur=srcs[src]
            for field,label in [('qty','الكمية'),('cartons','الكراتين'),('net_weight','الوزن'),('unit_price','سعر الوحدة'),('customs_value','القيمة الجمركية')]:
                a=float(base.get(field) or 0); b=float(cur.get(field) or 0)
                tol=max(0.01,abs(a)*0.01)
                if abs(a-b)>tol: dif.append({'source':src,'field':field,'label':label,'base':a,'value':b,'difference':round(b-a,4)})
            if norm_text(base.get('description'))!=norm_text(cur.get('description')) and (base.get('description') or cur.get('description')):
                dif.append({'source':src,'field':'description','label':'الوصف','base':base.get('description',''),'value':cur.get('description','')})
            if norm_text(base.get('barcode'))!=norm_text(cur.get('barcode')) and (base.get('barcode') or cur.get('barcode')):
                dif.append({'source':src,'field':'barcode','label':'الباركود','base':base.get('barcode',''),'value':cur.get('barcode','')})
        g['differences']=dif; g['status']='يوجد اختلاف' if dif else 'مطابق'
    result=list(groups.values())
    matched=sum(1 for x in result if x['status']=='مطابق'); different=sum(1 for x in result if x['status']=='يوجد اختلاف'); missing=sum(1 for x in result if x['status']=='ناقص مستندات')
    score=round((matched/len(result))*100,2) if result else 0
    return {'shipment_id':shipment_id,'items':result,'summary':{'total_items':len(result),'matched':matched,'different':different,'missing':missing,'score':score}}

@app.get('/api/shipments/{shipment_id}/reconciliation.csv')
def reconciliation_csv(shipment_id:int,s=Depends(db),u=Depends(current_user)):
    if not s.get(Shipment,shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    rows=s.query(DocumentItem).filter_by(shipment_id=shipment_id).all()
    out=io.StringIO(); w=csv.writer(out)
    w.writerow(['المفتاح','الوصف','الباركود','المستند','الكمية','الكراتين','الوزن الصافي','سعر الوحدة','القيمة الجمركية','العملة'])
    for r in rows: w.writerow([norm_text(r.barcode) or norm_text(r.description),r.description,r.barcode,r.source,r.qty,r.cartons,r.net_weight,r.unit_price,r.customs_value,r.currency])
    from fastapi.responses import Response
    return Response(content='\ufeff'+out.getvalue(),media_type='text/csv; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="shipment_{shipment_id}_reconciliation.csv"'})


# V1.3: XLSX/PDF document ingestion
try:
    from openpyxl import load_workbook
except Exception:
    load_workbook = None
try:
    from pypdf import PdfReader
except Exception:
    PdfReader = None

@app.post('/api/shipments/{shipment_id}/import-xlsx')
async def import_document_xlsx(shipment_id:int, source:str, file:UploadFile=File(...), replace_existing:bool=False, s=Depends(db), u=Depends(current_user)):
    if not s.get(Shipment,shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    src=canonical_source(source)
    if src not in {'invoice','packing_list','bill_of_lading','certificate_of_origin','customs_declaration'}: raise HTTPException(400,'نوع المستند غير مدعوم')
    if load_workbook is None: raise HTTPException(500,'مكتبة Excel غير مثبتة')
    raw=await file.read()
    try:
        wb=load_workbook(io.BytesIO(raw),read_only=True,data_only=True)
        ws=wb.active
        rows=list(ws.iter_rows(values_only=True))
    except Exception as e: raise HTTPException(400,f'تعذر قراءة Excel: {e}')
    if not rows: raise HTTPException(400,'ملف Excel فارغ')
    headers=[str(x or '').strip() for x in rows[0]]
    if not any(headers): raise HTTPException(400,'تعذر تحديد صف العناوين')
    if replace_existing: s.query(DocumentItem).filter_by(shipment_id=shipment_id,source=src).delete(synchronize_session=False)
    added=0
    for idx,vals in enumerate(rows[1:],1):
        row={headers[i]: vals[i] if i<len(vals) else '' for i in range(len(headers))}
        desc=row_value(row,'description','item','item_description','الصنف','الوصف')
        barcode=row_value(row,'barcode','sku','hs_code','باركود','الباركود')
        qty=csv_float(row_value(row,'qty','quantity','الكمية')); cartons=csv_float(row_value(row,'cartons','packages','carton','الكراتين','عدد الكراتين'))
        weight=csv_float(row_value(row,'net_weight','weight','net','الوزن','الوزن الصافي')); price=csv_float(row_value(row,'unit_price','price','unit_cost','سعر الوحدة','السعر'))
        customs=csv_float(row_value(row,'customs_value','customs','customs_amount','القيمة الجمركية')); currency=row_value(row,'currency','العملة') or 'USD'
        if not (desc or barcode): continue
        s.add(DocumentItem(shipment_id=shipment_id,source=src,line_no=idx,description=str(desc),barcode=str(barcode),qty=qty,cartons=cartons,net_weight=weight,unit_price=price,customs_value=customs,currency=str(currency))); added+=1
    s.commit(); audit(s,u,'import_xlsx','document_items',shipment_id)
    return {'shipment_id':shipment_id,'source':src,'file_name':file.filename or '','rows_read':max(0,len(rows)-1),'rows_added':added,'replaced':replace_existing}

@app.post('/api/shipments/{shipment_id}/extract-pdf')
async def extract_pdf(shipment_id:int, document_type:str='مستند', file:UploadFile=File(...), s=Depends(db), u=Depends(current_user)):
    if not s.get(Shipment,shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    if PdfReader is None: raise HTTPException(500,'مكتبة PDF غير مثبتة')
    raw=await file.read()
    try:
        reader=PdfReader(io.BytesIO(raw)); text='\n'.join((p.extract_text() or '') for p in reader.pages)
    except Exception as e: raise HTTPException(400,f'تعذر قراءة PDF: {e}')
    if not text.strip(): return {'shipment_id':shipment_id,'pages':len(reader.pages),'text':'','message':'ملف PDF لا يحتوي نصًا قابلاً للاستخراج؛ يحتاج OCR للصورة.'}
    digest=hashlib.sha256(raw).hexdigest()
    # Reuse the AI extraction parser when available in this version.
    data=_extract_fields(text)
    confidence=0
    if data: confidence=min(100,round(len(data)/8*100,2))
    z=AIExtraction(shipment_id=shipment_id,document_type=document_type,file_name=file.filename or '',sha256=digest,extracted_json=json.dumps(data,ensure_ascii=False),confidence=confidence,status='مراجعة',created_by=u.id)
    s.add(z); s.commit(); audit(s,u,'extract_pdf','ai_extraction',z.id)
    return {'id':z.id,'shipment_id':shipment_id,'pages':len(reader.pages),'characters':len(text),'text':text[:30000],'extracted':data,'confidence':confidence,'status':'مراجعة'}

# ===== V1.8 operations dashboard, alerts and due-date tracking =====
class ShipmentReminder(Base):
    __tablename__='shipment_reminders'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    shipment_id:Mapped[int]=mapped_column(ForeignKey('shipments.id'),index=True)
    title:Mapped[str]=mapped_column(String(180))
    due_date:Mapped[str]=mapped_column(String(20))
    status:Mapped[str]=mapped_column(String(30),default='مفتوح')
    notes:Mapped[str]=mapped_column(Text,default='')
    created_by:Mapped[int]=mapped_column(Integer,default=0)

class ShipmentStatusLog(Base):
    __tablename__='shipment_status_log'
    id:Mapped[int]=mapped_column(Integer,primary_key=True)
    shipment_id:Mapped[int]=mapped_column(ForeignKey('shipments.id'),index=True)
    old_status:Mapped[str]=mapped_column(String(50),default='')
    new_status:Mapped[str]=mapped_column(String(50))
    changed_at:Mapped[datetime]=mapped_column(DateTime,default=lambda:datetime.now(timezone.utc))
    user_id:Mapped[int]=mapped_column(Integer)

Base.metadata.create_all(engine)

class ReminderIn(BaseModel):
    title:str; due_date:str; notes:str=''

class ShipmentStatusIn(BaseModel):
    status:str

@app.get('/api/operations/alerts')
def operations_alerts(s=Depends(db),u=Depends(current_user)):
    today=datetime.now(timezone.utc).date().isoformat()
    alerts=[]
    for sh in s.query(Shipment).all():
        missing=s.query(ShipmentChecklist).filter_by(shipment_id=sh.id,required=True,received=False).count()
        if missing:
            alerts.append({'type':'document','severity':'high','shipment_id':sh.id,'message':f'الشحنة {sh.id}: مستندات ناقصة ({missing})'})
    for inv in s.query(Invoice).filter(Invoice.posted==True).all():
        paid=sum(v.amount for v in s.query(Voucher).filter(Voucher.invoice_id==inv.id,Voucher.posted==True,Voucher.voucher_type=='قبض').all())
        remaining=round(inv.total-paid,2)
        if remaining>0:
            alerts.append({'type':'receivable','severity':'medium','invoice_id':inv.id,'message':f'فاتورة {inv.number} غير مسددة، المتبقي {remaining}'})
    for r in s.query(ShipmentReminder).filter(ShipmentReminder.status=='مفتوح').all():
        sev='high' if r.due_date < today else ('medium' if r.due_date==today else 'low')
        alerts.append({'type':'reminder','severity':sev,'shipment_id':r.shipment_id,'reminder_id':r.id,'message':r.title,'due_date':r.due_date})
    return {'date':today,'count':len(alerts),'alerts':alerts[:200]}

@app.get('/api/operations/dashboard')
def operations_dashboard(s=Depends(db),u=Depends(current_user)):
    statuses={}
    for sh in s.query(Shipment).all(): statuses[sh.status]=statuses.get(sh.status,0)+1
    costs=s.query(ShipmentCharge).filter_by(approved=True).all()
    approved_cost=sum(x.amount for x in costs)
    invoices=s.query(Invoice).all()
    receivables=sum(max(0,(x.total or 0)-(x.paid or 0)) for x in invoices)
    return {'shipments_total':len(s.query(Shipment).all()),'shipments_by_status':statuses,'approved_costs':round(approved_cost,2),'receivables':round(receivables,2),'open_invoices':sum(1 for x in invoices if x.status!='مسددة'),'customers':s.query(Customer).count(),'suppliers':s.query(Supplier).count(),'pending_approvals':s.query(ApprovalRequest).filter_by(status='معلق').count()}

@app.post('/api/shipments/{shipment_id}/reminders')
def add_reminder(shipment_id:int,x:ReminderIn,s=Depends(db),u=Depends(current_user)):
    if not s.get(Shipment,shipment_id): raise HTTPException(404,'الشحنة غير موجودة')
    r=ShipmentReminder(shipment_id=shipment_id,title=x.title,due_date=x.due_date,notes=x.notes,created_by=u.id)
    s.add(r); s.commit(); audit(s,u,'create','shipment_reminder',r.id)
    return {'id':r.id,'shipment_id':shipment_id,'title':r.title,'due_date':r.due_date,'status':r.status}

@app.get('/api/shipments/{shipment_id}/reminders')
def list_reminders(shipment_id:int,s=Depends(db),u=Depends(current_user)):
    return [{'id':x.id,'title':x.title,'due_date':x.due_date,'status':x.status,'notes':x.notes} for x in s.query(ShipmentReminder).filter_by(shipment_id=shipment_id).order_by(ShipmentReminder.due_date).all()]

@app.put('/api/shipments/{shipment_id}/status')
def update_shipment_status(shipment_id:int,x:ShipmentStatusIn,s=Depends(db),u=Depends(current_user)):
    sh=s.get(Shipment,shipment_id)
    if not sh: raise HTTPException(404,'الشحنة غير موجودة')
    old=sh.status; sh.status=x.status
    s.add(ShipmentStatusLog(shipment_id=shipment_id,old_status=old,new_status=x.status,user_id=u.id)); s.commit(); audit(s,u,'status_change','shipment',shipment_id)
    return {'shipment_id':shipment_id,'old_status':old,'status':x.status}

@app.get('/api/shipments/{shipment_id}/status-history')
def shipment_status_history(shipment_id:int,s=Depends(db),u=Depends(current_user)):
    return [{'old_status':x.old_status,'new_status':x.new_status,'changed_at':x.changed_at.isoformat(),'user_id':x.user_id} for x in s.query(ShipmentStatusLog).filter_by(shipment_id=shipment_id).order_by(ShipmentStatusLog.id.desc()).all()]



# ===== V3.6 unified customer/service/claim/collection center =====
def _valid_date_range(date_from, date_to):
    if date_from and date_to and date_from > date_to:
        raise HTTPException(400,'تاريخ البداية أكبر من النهاية')

def _customer_receipts(s, customer_id, date_from=None, date_to=None):
    q=s.query(Voucher).join(Invoice,Invoice.id==Voucher.invoice_id).filter(
        Invoice.customer_id==customer_id, Voucher.posted==True, Voucher.voucher_type=='قبض')
    if date_from: q=q.filter(Voucher.date>=date_from)
    if date_to: q=q.filter(Voucher.date<=date_to)
    return q.order_by(Voucher.date,Voucher.id).all()

@app.get('/api/customers/{customer_id}/360')
def customer_360(customer_id:int,date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    """Unified customer center: profile, importers, services, claims, posted invoices and posted collections."""
    _valid_date_range(date_from,date_to)
    c=s.get(Customer,customer_id)
    if not c: raise HTTPException(404,'العميل غير موجود')
    iq=s.query(Invoice).filter(Invoice.customer_id==customer_id,Invoice.posted==True)
    sq=s.query(CustomerService,Service).join(Service,Service.id==CustomerService.service_id).filter(CustomerService.customer_id==customer_id)
    cq=s.query(Claim).filter(Claim.customer_id==customer_id)
    if date_from:
        iq=iq.filter(Invoice.date>=date_from); sq=sq.filter(CustomerService.date>=date_from); cq=cq.filter(Claim.date>=date_from)
    if date_to:
        iq=iq.filter(Invoice.date<=date_to); sq=sq.filter(CustomerService.date<=date_to); cq=cq.filter(Claim.date<=date_to)
    invs=iq.order_by(Invoice.date,Invoice.id).all()
    services=sq.order_by(CustomerService.date,CustomerService.id).all()
    claims=cq.order_by(Claim.date,Claim.id).all()
    receipts=_customer_receipts(s,customer_id,date_from,date_to)
    invoice_total=round(sum(x.total or 0 for x in invs),2)
    receipt_total=round(sum(x.amount or 0 for x in receipts),2)
    service_total=round(sum((x.quantity or 0)*(x.unit_price or 0) for x,_ in services),2)
    claim_total=round(sum(x.amount or 0 for x in claims if x.status!='ملغاة'),2)
    return {
        'customer':{'id':c.id,'name':c.name,'phone':c.phone,'tax_no':c.tax_no,'notes':c.notes},
        'filters':{'date_from':date_from,'date_to':date_to},
        'importers':[{'id':x.id,'name':x.importer_name,'trade_name':x.trade_name,'authorization_from':x.authorization_from,'authorization_to':x.authorization_to,'tax_no':x.tax_no,'commercial_register':x.commercial_register,'activity':x.activity} for x in s.query(CustomerImporter).filter_by(customer_id=customer_id).order_by(CustomerImporter.id).all()],
        'services':[{'id':x.id,'service_id':x.service_id,'service_name':sv.name,'service_type':sv.service_type,'date':x.date,'quantity':x.quantity,'unit_price':x.unit_price,'total':round(x.quantity*x.unit_price,2),'description':x.description,'invoice_id':x.invoice_id,'status':x.status} for x,sv in services],
        'claims':[{'id':x.id,'claim_no':x.claim_no,'date':x.date,'subject':x.subject,'amount':x.amount,'status':x.status,'shipment_id':x.shipment_id,'notes':x.notes} for x in claims],
        'invoices':[{'id':x.id,'number':x.number,'date':x.date,'total':x.total,'status':x.status,'posted':x.posted} for x in invs],
        'collections':[{'id':x.id,'number':x.number,'date':x.date,'amount':x.amount,'reference':x.reference,'invoice_id':x.invoice_id,'posted':x.posted} for x in receipts],
        'summary':{'service_total':service_total,'claim_total':claim_total,'invoiced':invoice_total,'collected':receipt_total,'outstanding':round(invoice_total-receipt_total,2),'service_count':len(services),'claim_count':len(claims),'invoice_count':len(invs),'collection_count':len(receipts)}
    }

@app.post('/api/customers/{customer_id}/claims/{claim_id}/generate-invoice')
def claim_to_invoice(customer_id:int,claim_id:int,date:str,number:str,s=Depends(db),u=Depends(current_user)):
    if not has_permission(s,u,'accounting','create'): raise HTTPException(403,'لا تملك صلاحية إنشاء الفواتير')
    c=s.get(Customer,customer_id)
    z=s.get(Claim,claim_id)
    if not c or not z or z.customer_id!=customer_id: raise HTTPException(404,'المطالبة غير موجودة')
    if z.status=='ملغاة': raise HTTPException(400,'لا يمكن إصدار فاتورة لمطالبة ملغاة')
    if z.amount<=0: raise HTTPException(400,'قيمة المطالبة يجب أن تكون أكبر من صفر')
    if s.query(Invoice).filter_by(number=number).first(): raise HTTPException(409,'رقم الفاتورة موجود')
    existing=s.query(InvoiceLine).join(Invoice,Invoice.id==InvoiceLine.invoice_id).filter(Invoice.customer_id==customer_id,InvoiceLine.description=='مطالبة '+z.claim_no).first()
    if existing: raise HTTPException(409,'تم إنشاء فاتورة لهذه المطالبة سابقًا')
    inv=Invoice(number=number,date=date,customer_id=customer_id,description='فاتورة مطالبة '+z.claim_no,total=round(z.amount,2))
    s.add(inv); s.flush()
    s.add(InvoiceLine(invoice_id=inv.id,description='مطالبة '+z.claim_no,qty=1,unit_price=round(z.amount,2),total=round(z.amount,2)))
    z.status='مطالبة مرسلة'
    try:
        s.commit(); audit(s,u,'create','claim_invoice',inv.id)
        return {'id':inv.id,'number':inv.number,'customer_id':customer_id,'claim_id':claim_id,'total':inv.total,'posted':False}
    except Exception:
        s.rollback(); raise

@app.get('/api/customers/{customer_id}/collections')
def customer_collections(customer_id:int,date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    _valid_date_range(date_from,date_to)
    if not s.get(Customer,customer_id): raise HTTPException(404,'العميل غير موجود')
    rows=_customer_receipts(s,customer_id,date_from,date_to)
    return {'customer_id':customer_id,'date_from':date_from,'date_to':date_to,'count':len(rows),'total':round(sum(x.amount for x in rows),2),'rows':[{'id':x.id,'number':x.number,'date':x.date,'amount':x.amount,'reference':x.reference,'description':x.description,'invoice_id':x.invoice_id} for x in rows]}

@app.post('/api/customers/{customer_id}/services/{service_row_id}/cancel')
def cancel_customer_service(customer_id:int,service_row_id:int,s=Depends(db),u=Depends(current_user)):
    z=s.get(CustomerService,service_row_id)
    if not z or z.customer_id!=customer_id: raise HTTPException(404,'الخدمة غير موجودة')
    if z.invoice_id: raise HTTPException(400,'لا يمكن إلغاء خدمة مرتبطة بفاتورة')
    if z.status=='ملغاة': raise HTTPException(409,'الخدمة ملغاة بالفعل')
    z.status='ملغاة'; s.commit(); audit(s,u,'cancel','customer_service',z.id)
    return {'id':z.id,'customer_id':customer_id,'status':z.status}

# ===== V3.4 reports =====
@app.get('/api/reports/general-ledger')
def general_ledger_all(account_code:str|None=None,date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    q=s.query(JournalLine,JournalEntry).join(JournalEntry,JournalEntry.id==JournalLine.entry_id)
    if account_code: q=q.filter(JournalLine.account_code==account_code)
    if date_from: q=q.filter(JournalEntry.date>=date_from)
    if date_to: q=q.filter(JournalEntry.date<=date_to)
    rows=[]; running={}
    for l,e in q.order_by(JournalEntry.date,JournalEntry.id,JournalLine.id).all():
        bal=running.get(l.account_code,0.0)+l.debit-l.credit; running[l.account_code]=round(bal,2)
        a=s.query(Account).filter_by(code=l.account_code).first()
        rows.append({'date':e.date,'entry_id':e.id,'account_code':l.account_code,'account_name':a.name if a else '', 'description':l.description or e.description,'debit':round(l.debit,2),'credit':round(l.credit,2),'balance':round(bal,2)})
    return {'date_from':date_from,'date_to':date_to,'account_code':account_code,'rows':rows,'totals':{'debit':round(sum(x['debit'] for x in rows),2),'credit':round(sum(x['credit'] for x in rows),2)}}

@app.get('/api/reports/cash-bank')
def cash_bank_report(date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    # Uses journal movements for accounts classified/named as cash or bank.
    accounts=[]
    for a in s.query(Account).all():
        n=(a.name or '').lower(); t=(a.account_type or '').lower()
        if t in ('cash','bank') or any(k in n for k in ('cash','bank','صندوق','بنك','البنك')):
            q=s.query(JournalLine,JournalEntry).join(JournalEntry,JournalEntry.id==JournalLine.entry_id).filter(JournalLine.account_code==a.code)
            if date_from:q=q.filter(JournalEntry.date>=date_from)
            if date_to:q=q.filter(JournalEntry.date<=date_to)
            rows=q.all(); debit=sum(l.debit for l,e in rows); credit=sum(l.credit for l,e in rows)
            accounts.append({'account_code':a.code,'account_name':a.name,'debit':round(debit,2),'credit':round(credit,2),'balance':round(debit-credit,2)})
    return {'date_from':date_from,'date_to':date_to,'accounts':accounts,'totals':{'debit':round(sum(x['debit'] for x in accounts),2),'credit':round(sum(x['credit'] for x in accounts),2),'balance':round(sum(x['balance'] for x in accounts),2)}}

# ===== V3.8 reporting, printing and export =====
def _v38_date_range(date_from, date_to):
    _valid_date_range(date_from, date_to)

def _xlsx_response(headers, rows, filename, sheet='Report'):
    try:
        from openpyxl import Workbook
        from openpyxl.utils import get_column_letter
    except Exception:
        raise HTTPException(500,'مكتبة Excel غير مثبتة')
    wb=Workbook(); ws=wb.active; ws.title=sheet[:31]
    ws.append(headers)
    for row in rows: ws.append(list(row))
    ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions
    for col in range(1,len(headers)+1):
        vals=[str(ws.cell(r,col).value or '') for r in range(1,min(ws.max_row,100)+1)]
        ws.column_dimensions[get_column_letter(col)].width=min(45,max(12,max(map(len,vals),default=12)+2))
    bio=io.BytesIO(); wb.save(bio); bio.seek(0)
    return Response(content=bio.getvalue(),media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',headers={'Content-Disposition':f'attachment; filename="{filename}"'})

def _v38_gl_rows(s, account_code=None, date_from=None, date_to=None):
    data=general_ledger_all(account_code,date_from,date_to,s,u=None)
    return data['rows']

@app.get('/api/reports/general-ledger.csv')
def general_ledger_csv_v38(account_code:str|None=None,date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    _v38_date_range(date_from,date_to); rows=_v38_gl_rows(s,account_code,date_from,date_to)
    out=io.StringIO(); w=csv.writer(out); w.writerow(['التاريخ','رقم القيد','رمز الحساب','اسم الحساب','البيان','مدين','دائن','الرصيد'])
    for x in rows: w.writerow([x['date'],x['entry_id'],x['account_code'],x['account_name'],x['description'],x['debit'],x['credit'],x['balance']])
    return Response(content='\ufeff'+out.getvalue(),media_type='text/csv; charset=utf-8',headers={'Content-Disposition':'attachment; filename="general_ledger_v38.csv"'})

@app.get('/api/reports/general-ledger.xlsx')
def general_ledger_xlsx_v38(account_code:str|None=None,date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    _v38_date_range(date_from,date_to); rows=_v38_gl_rows(s,account_code,date_from,date_to)
    return _xlsx_response(['التاريخ','رقم القيد','رمز الحساب','اسم الحساب','البيان','مدين','دائن','الرصيد'],[[x['date'],x['entry_id'],x['account_code'],x['account_name'],x['description'],x['debit'],x['credit'],x['balance']] for x in rows],'general_ledger_v38.xlsx','دفتر الأستاذ')

@app.get('/api/reports/cash-bank.xlsx')
def cash_bank_xlsx_v38(date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    _v38_date_range(date_from,date_to); data=cash_bank_report(date_from,date_to,s,u=None)
    return _xlsx_response(['رمز الحساب','اسم الحساب','مدين','دائن','الرصيد'],[[x['account_code'],x['account_name'],x['debit'],x['credit'],x['balance']] for x in data['accounts']],'cash_bank_v38.xlsx','الصندوق والبنك')

@app.get('/api/reports/trial-balance.xlsx')
def trial_balance_xlsx_v38(date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    _v38_date_range(date_from,date_to); data=trial_balance_v2(date_from,date_to,s,u=None)
    return _xlsx_response(['رمز الحساب','اسم الحساب','مدين','دائن','الرصيد'],[[x['code'],x['name'],x['debit'],x['credit'],x['balance']] for x in data['rows']],'trial_balance_v38.xlsx','ميزان المراجعة')

@app.get('/api/reports/profit-loss.xlsx')
def profit_loss_xlsx_v38(date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    _v38_date_range(date_from,date_to); data=profit_loss_v2(date_from,date_to,s,u=None)
    rows=[[x['code'],x['name'],x['account_type'],x['amount']] for x in data['accounts']]
    rows += [['','','الإيرادات',data['income']],['','','المصروفات',data['expenses']],['','','صافي الربح',data['net_profit']]]
    return _xlsx_response(['رمز الحساب','اسم الحساب','النوع','القيمة'],rows,'profit_loss_v38.xlsx','الأرباح والخسائر')

@app.get('/api/reports/balance-sheet.xlsx')
def balance_sheet_xlsx_v38(date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    data=balance_sheet_v2(date_to,s,u=None)
    return _xlsx_response(['البند','القيمة'],[['الأصول',data['assets']],['الالتزامات',data['liabilities']],['حقوق الملكية',data['equity']],['الربح الحالي',data['current_profit']],['الفرق',data['difference']]],'balance_sheet_v38.xlsx','الميزانية')

@app.get('/api/reports/profit-loss-range.pdf')
def profit_loss_pdf_v38(date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    _v38_date_range(date_from,date_to); data=profit_loss_v2(date_from,date_to,s,u=None)
    rows=[[x['code'],x['name'],x['amount']] for x in data['accounts']]
    rows += [['','الإيرادات',data['income']],['','المصروفات',data['expenses']],['','صافي الربح',data['net_profit']]]
    path=_make_pdf('الأرباح والخسائر',['الحساب','اسم الحساب','القيمة'],rows,'profit_loss_v38.pdf')
    return FileResponse(path,media_type='application/pdf',filename='profit_loss_v38.pdf')

@app.get('/api/reports/trial-balance-range.pdf')
def trial_balance_pdf_v38(date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    _v38_date_range(date_from,date_to); data=trial_balance_v2(date_from,date_to,s,u=None)
    rows=[[x['code'],x['name'],x['debit'],x['credit'],x['balance']] for x in data['rows']]
    path=_make_pdf('ميزان المراجعة',['الحساب','اسم الحساب','مدين','دائن','الرصيد'],rows,'trial_balance_v38.pdf')
    return FileResponse(path,media_type='application/pdf',filename='trial_balance_v38.pdf')

@app.get('/api/reports/summary.xlsx')
def summary_xlsx_v38(date_from:str|None=None,date_to:str|None=None,s=Depends(db),u=Depends(current_user)):
    _v38_date_range(date_from,date_to)
    pl=profit_loss_v2(date_from,date_to,s,u=None)
    tb=trial_balance_v2(date_from,date_to,s,u=None)
    rows=[['إجمالي المدين',tb['total_debit']],['إجمالي الدائن',tb['total_credit']],['الإيرادات',pl['income']],['المصروفات',pl['expenses']],['صافي الربح',pl['net_profit']]]
    return _xlsx_response(['المؤشر','القيمة'],rows,'financial_summary_v38.xlsx','ملخص مالي')
