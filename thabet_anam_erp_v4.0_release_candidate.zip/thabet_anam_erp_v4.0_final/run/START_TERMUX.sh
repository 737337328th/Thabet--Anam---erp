#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")/.."
export THABET_SECRET="${THABET_SECRET:-change-this-secret-before-production-32chars-minimum}"
export DATABASE_URL="${DATABASE_URL:-sqlite:///./thabet.db}"
if ! command -v python >/dev/null 2>&1; then
  echo 'Python غير مثبت. نفذ: pkg update && pkg install python'
  exit 1
fi
python -m pip install -r backend/requirements.txt
python -m uvicorn backend.app.main:app --host 0.0.0.0 --port 8000 >/tmp/thabet-backend.log 2>&1 &
BACK_PID=$!
trap 'kill $BACK_PID 2>/dev/null || true' EXIT
python -m http.server 8081 --bind 127.0.0.1 --directory frontend >/tmp/thabet-frontend.log 2>&1 &
FRONT_PID=$!
trap 'kill $FRONT_PID 2>/dev/null || true' EXIT
sleep 2
echo 'ثابت أنعم ERP V4.0 يعمل على: http://127.0.0.1:8081'
wait $BACK_PID
