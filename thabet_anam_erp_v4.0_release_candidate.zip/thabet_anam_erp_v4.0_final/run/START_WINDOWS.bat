@echo off
cd /d "%~dp0.."
if not exist .env copy .env.example .env >nul
docker compose up -d --build
if errorlevel 1 exit /b 1
echo ثابت أنعم يعمل على http://localhost:8080
pause
