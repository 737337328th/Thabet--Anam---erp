#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
if [ ! -f .env ]; then cp .env.example .env; fi
if command -v docker >/dev/null 2>&1 && docker compose version >/dev/null 2>&1; then
  docker compose up -d --build
  echo 'ثابت أنعم يعمل على: http://localhost:8080'
else
  echo 'Docker غير متوفر. ثبّت Docker ثم أعد التشغيل.'
  exit 1
fi
