#!/usr/bin/env bash
set -euo pipefail
# تشغيل أولي على Ubuntu في خادم سحابي. لا يحتوي على مفاتيح أو أسرار.
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
command -v docker >/dev/null 2>&1 || { echo 'Docker غير مثبت. ثبته أولاً من المصدر الرسمي.'; exit 1; }
cp -n .env.example .env || true
printf '\nعدّل .env قبل التشغيل، ثم نفّذ: docker compose up -d --build\n'
printf 'بعد التشغيل افتح منفذ التطبيق عبر reverse proxy/HTTPS ولا تعرض PostgreSQL للإنترنت.\n'
