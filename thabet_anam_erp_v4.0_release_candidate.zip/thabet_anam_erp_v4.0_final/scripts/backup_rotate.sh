#!/usr/bin/env bash
set -euo pipefail
# نسخ احتياطي محلي مع SHA-256 وحذف النسخ الأقدم من 14 يوماً.
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/scripts/backups"
STAMP=$(date +%Y%m%d_%H%M%S)
OUT="$ROOT/scripts/backups/thabet_anam_$STAMP.sql.gz"
docker compose exec -T db pg_dump -U "${POSTGRES_USER:-thabet}" "${POSTGRES_DB:-thabet_anam}" | gzip -9 > "$OUT"
sha256sum "$OUT" > "$OUT.sha256"
find "$ROOT/scripts/backups" -type f -mtime +14 -delete
echo "Backup created: $OUT"
