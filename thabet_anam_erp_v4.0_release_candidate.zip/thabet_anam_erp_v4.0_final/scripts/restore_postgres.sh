#!/usr/bin/env sh
set -eu
FILE=${1:?حدد ملف النسخة الاحتياطية .dump}
test -f "$FILE"
docker compose exec -T db pg_restore -U "${POSTGRES_USER:-thabet}" -d "${POSTGRES_DB:-thabet_anam}" --clean --if-exists --no-owner < "$FILE"
echo "Restore completed."
