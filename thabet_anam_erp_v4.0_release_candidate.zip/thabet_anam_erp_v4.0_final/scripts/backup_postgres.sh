#!/usr/bin/env sh
set -eu
mkdir -p backups
STAMP=$(date +%Y%m%d_%H%M%S)
FILE="backups/thabet_anam_${STAMP}.dump"
docker compose exec -T db pg_dump -Fc -U "${POSTGRES_USER:-thabet}" -d "${POSTGRES_DB:-thabet_anam}" > "$FILE"
sha256sum "$FILE" > "$FILE.sha256"
echo "Backup created: $FILE"
