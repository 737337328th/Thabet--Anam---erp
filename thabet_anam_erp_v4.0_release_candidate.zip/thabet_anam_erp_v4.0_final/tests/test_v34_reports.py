import os, tempfile
os.environ["DATABASE_URL"]="sqlite:///"+os.path.join(tempfile.gettempdir(),"thabet_anam_v34_test.db")
os.environ["THABET_SECRET"]="test-secret"
from fastapi.testclient import TestClient
from app.main import app

def test_v34_routes_require_auth():
    with TestClient(app) as c:
        assert c.get("/api/reports/general-ledger").status_code==401
        assert c.get("/api/reports/cash-bank").status_code==401
