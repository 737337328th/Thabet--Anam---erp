import os
from fastapi.testclient import TestClient
from app.main import app

def login(c, username='admin', password='admin123'):
    r=c.post('/api/auth/login',json={'username':username,'password':password})
    assert r.status_code==200
    return {'Authorization':'Bearer '+r.json()['access_token']}

def test_v37_roles_permissions_and_audit_filters():
    with TestClient(app) as c:
        h=login(c)
        r=c.get('/api/admin/roles',headers=h); assert r.status_code==200
        roles={x['role'] for x in r.json()}; assert 'manager' in roles and 'user' in roles
        r=c.get('/api/admin/permissions',params={'role':'user'},headers=h); assert r.status_code==200
        assert all(x['role']=='user' for x in r.json())
        r=c.put('/api/admin/permissions',json={'role':'user','module':'reports','action':'view','allowed':False},headers=h)
        assert r.status_code==200 and r.json()['allowed'] is False
        r=c.get('/api/admin/permissions',params={'role':'user'},headers=h); assert any(x['module']=='reports' and x['action']=='view' and not x['allowed'] for x in r.json())
        r=c.get('/api/audit',params={'action':'permission','limit':20},headers=h); assert r.status_code==200
        assert any(x['entity']=='role' for x in r.json())

def test_v37_user_management_safety():
    with TestClient(app) as c:
        h=login(c)
        r=c.post('/api/users',json={'username':f'v40user_unique_{os.getpid()}','name':'V37','password':'secret123','role':'user','active':True},headers=h)
        assert r.status_code==200
        uid=r.json()['id']
        r=c.patch(f'/api/users/{uid}',json={'active':False},headers=h); assert r.status_code==200
        r=c.patch(f'/api/users/{uid}',json={'active':True,'role':'manager'},headers=h); assert r.status_code==200
        r=c.patch('/api/users/999999',json={'active':False},headers=h); assert r.status_code==404
