import os, tempfile
from fastapi.testclient import TestClient

def fresh_client():
    db=os.path.join(tempfile.gettempdir(),f'thabet_anam_v36_{os.getpid()}.db')
    try: os.remove(db)
    except FileNotFoundError: pass
    os.environ['DATABASE_URL']='sqlite:///'+db
    os.environ['THABET_SECRET']='test-secret'
    from app.main import app, Base, engine
    Base.metadata.create_all(engine)
    return TestClient(app)

def login(c):
    r=c.post('/api/auth/login',json={'username':'admin','password':'admin123'})
    assert r.status_code==200, r.text
    return {'Authorization':'Bearer '+r.json()['access_token']}

def test_v36_customer_360_and_collection():
    c=fresh_client(); h=login(c)
    r=c.post('/api/customers',headers=h,json={'name':'عميل V36','phone':'700000000'})
    assert r.status_code==200, r.text
    cid=r.json()['id']
    r=c.post('/api/services',headers=h,json={'code':f'SVC36-{os.getpid()}','name':'خدمة تخليص V36','service_type':'تخليص','default_price':100})
    assert r.status_code==200, r.text
    sid=r.json()['id']
    r=c.post(f'/api/customers/{cid}/services',headers=h,json={'service_id':sid,'date':'2026-12-10','quantity':2,'unit_price':100,'description':'خدمة'})
    assert r.status_code==200, r.text
    r=c.post(f'/api/customers/{cid}/claims',headers=h,json={'claim_no':f'CL36-{os.getpid()}','date':'2026-12-11','subject':'مطالبة خدمة','amount':200,'status':'جديدة'})
    assert r.status_code==200, r.text
    claim_id=r.json()['id']
    r=c.post(f'/api/customers/{cid}/claims/{claim_id}/generate-invoice',headers=h,params={'date':'2026-12-12','number':f'INV36-{os.getpid()}'})
    assert r.status_code==200, r.text
    inv_id=r.json()['id']
    assert c.post(f'/api/invoices/{inv_id}/post',headers=h).status_code==200
    r=c.post('/api/vouchers',headers=h,json={'number':f'RC36-{os.getpid()}','date':'2026-12-13','voucher_type':'قبض','cash_box':'الصندوق','reference':'تحصيل','description':'تحصيل V36','amount':200,'account_code':'1100','invoice_id':inv_id})
    assert r.status_code==200, r.text
    vid=r.json()['id']
    assert c.post(f'/api/vouchers/{vid}/post',headers=h).status_code==200
    r=c.get(f'/api/customers/{cid}/360',headers=h)
    assert r.status_code==200, r.text
    d=r.json()['summary']
    assert d['service_total']==200.0 and d['invoiced']==200.0 and d['collected']==200.0 and d['outstanding']==0.0
    r=c.get(f'/api/customers/{cid}/collections',headers=h)
    assert r.status_code==200 and r.json()['total']==200.0

def test_v36_cancel_unbilled_service_only():
    c=fresh_client(); h=login(c)
    cid=c.post('/api/customers',headers=h,json={'name':'عميل إلغاء'}).json()['id']
    sid=c.post('/api/services',headers=h,json={'code':f'SVC36C-{os.getpid()}','name':'خدمة قابلة للإلغاء','service_type':'تخليص','default_price':50}).json()['id']
    row=c.post(f'/api/customers/{cid}/services',headers=h,json={'service_id':sid,'date':'2026-12-10','quantity':1}).json()
    r=c.post(f'/api/customers/{cid}/services/{row["id"]}/cancel',headers=h)
    assert r.status_code==200 and r.json()['status']=='ملغاة'
