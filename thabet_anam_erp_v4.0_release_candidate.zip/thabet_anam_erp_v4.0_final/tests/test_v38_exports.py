from fastapi.testclient import TestClient
from app.main import app

def login(c):
    r=c.post('/api/auth/login',json={'username':'admin','password':'admin123'}); assert r.status_code==200
    return {'Authorization':'Bearer '+r.json()['access_token']}

def test_v38_export_routes_require_auth():
    with TestClient(app) as c:
        for p in ['/api/reports/general-ledger.xlsx','/api/reports/general-ledger.csv','/api/reports/trial-balance.xlsx','/api/reports/profit-loss.xlsx','/api/reports/balance-sheet.xlsx','/api/reports/cash-bank.xlsx','/api/reports/summary.xlsx']:
            assert c.get(p).status_code==401

def test_v38_exports_authenticated_and_date_validation():
    with TestClient(app) as c:
        h=login(c)
        for p in ['/api/reports/general-ledger.xlsx','/api/reports/general-ledger.csv','/api/reports/trial-balance.xlsx','/api/reports/profit-loss.xlsx','/api/reports/balance-sheet.xlsx','/api/reports/cash-bank.xlsx','/api/reports/summary.xlsx']:
            r=c.get(p,headers=h); assert r.status_code==200, (p,r.text[:200])
        r=c.get('/api/reports/profit-loss-range.pdf',params={'date_from':'2026-09-10','date_to':'2026-09-01'},headers=h)
        assert r.status_code==400
