from fastapi.testclient import TestClient
from app.main import app

def login(c):
    r=c.post('/api/auth/login',json={'username':'admin','password':'admin123'})
    assert r.status_code==200
    return {'Authorization':'Bearer '+r.json()['access_token']}

def test_v40_public_health():
    with TestClient(app) as c:
        r=c.get('/api/system/health')
        assert r.status_code==200
        assert r.json()['status']=='ok'
        assert r.json()['version']=='4.0.0'

def test_v40_integrity_endpoint_is_manager_only():
    with TestClient(app) as c:
        h=login(c)
        r=c.get('/api/admin/integrity/full',headers=h)
        assert r.status_code==200
        d=r.json()
        assert d['version']=='4.0.0'
        assert 'findings' in d

def test_v40_overlapping_period_rejected():
    with TestClient(app) as c:
        h=login(c)
        r=c.post('/api/admin/fiscal-periods',headers=h,json={'name':'V40_A_'+str(__import__('os').getpid()),'start_date':'2099-01-01','end_date':'2099-12-31','closed':False})
        assert r.status_code==200
        r=c.post('/api/admin/fiscal-periods',headers=h,json={'name':'V40_B_'+str(__import__('os').getpid()),'start_date':'2099-06-01','end_date':'2100-05-31','closed':False})
        assert r.status_code==200
        pid=r.json()['id']
        r=c.post(f'/api/admin/fiscal-periods/{pid}/close-year',headers=h)
        assert r.status_code==409

def test_v40_date_range_validation():
    with TestClient(app) as c:
        h=login(c)
        r=c.get('/api/reports/expenses',params={'date_from':'2026-12-31','date_to':'2026-01-01'},headers=h)
        assert r.status_code==400
