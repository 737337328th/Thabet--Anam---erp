from fastapi.testclient import TestClient
from app.main import app, SessionLocal, FiscalPeriod, FiscalClose

def login(c):
    r=c.post('/api/auth/login',json={'username':'admin','password':'admin123'})
    assert r.status_code==200
    return {'Authorization':'Bearer '+r.json()['access_token']}

def test_schema_health_and_version():
    with TestClient(app) as c:
        h=login(c)
        r=c.get('/api/system/schema',headers=h)
        assert r.status_code==200
        data=r.json()
        assert data['application_version']=='4.0.0'
        assert data['schema_version']=='4.0.0'
        assert data['status']=='ok'

def test_zero_profit_fiscal_close_is_valid():
    with TestClient(app) as c:
        h=login(c)
        s=SessionLocal()
        name=f'V39_ZERO_{__import__("os").getpid()}'
        p=s.query(FiscalPeriod).filter_by(name=name).first()
        if not p:
            p=FiscalPeriod(name=name,start_date='2098-01-01',end_date='2098-01-01',closed=False); s.add(p); s.commit()
        else:
            p.closed=False; s.query(FiscalClose).filter_by(period_id=p.id).delete(); s.commit()
        pid=p.id; s.close()
        r=c.post(f'/api/admin/fiscal-periods/{pid}/close-year',headers=h)
        assert r.status_code==200
        assert r.json()['journal_entry_id'] is None
        s=SessionLocal(); fc=s.query(FiscalClose).filter_by(period_id=pid).first(); assert fc and fc.journal_entry_id is None and fc.net_profit==0; s.close()
