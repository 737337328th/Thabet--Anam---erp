"""V2.9 smoke/integration checks. Run from backend with pytest after installing requirements."""
import os, tempfile
_db=os.path.join(tempfile.gettempdir(),'thabet_anam_v29_test.db')
try:
    os.remove(_db)
except FileNotFoundError:
    pass
os.environ['DATABASE_URL']='sqlite:///'+_db
os.environ['THABET_SECRET']='test-secret-32-characters-long-0001'
from fastapi.testclient import TestClient
from app.main import app

def test_root_and_ledger_routes():
    with TestClient(app) as c:
        r=c.get('/')
        assert r.status_code==200 and r.json()['version']=='4.0.0'


def test_ledger_requires_auth():
    with TestClient(app) as c: assert c.get('/api/accounting/ledger/1000').status_code==401
