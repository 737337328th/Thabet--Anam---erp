import os,sys,tempfile
sys.path.insert(0,os.path.join(os.path.dirname(__file__),'..','backend'))
os.environ['DATABASE_URL']='sqlite:///'+os.path.join(tempfile.gettempdir(),'thabet_anam_v30_test.db')
os.environ['THABET_SECRET']='test-secret'
from fastapi.testclient import TestClient
from app.main import app

def test_root_v30():
    with TestClient(app) as c: assert c.get('/').json()['version']=='4.0.0'

def test_controls_requires_auth():
    with TestClient(app) as c: assert c.get('/api/accounting/controls').status_code==401
