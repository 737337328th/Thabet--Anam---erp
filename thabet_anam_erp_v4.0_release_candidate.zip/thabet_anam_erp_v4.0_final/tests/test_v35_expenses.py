import os, tempfile
from fastapi.testclient import TestClient


def fresh_client():
    db=os.path.join(tempfile.gettempdir(),'thabet_anam_v35_test.db')
    try: os.remove(db)
    except FileNotFoundError: pass
    os.environ['DATABASE_URL']='sqlite:///'+db
    os.environ['THABET_SECRET']='test-secret'
    from app.main import app, Base, engine, SessionLocal, Expense, JournalLine, JournalEntry
    Base.metadata.create_all(engine)
    ss=SessionLocal()
    try:
        ss.query(Expense).delete(synchronize_session=False)
        ss.query(JournalLine).delete(synchronize_session=False)
        ss.query(JournalEntry).delete(synchronize_session=False)
        ss.commit()
    finally:
        ss.close()
    return TestClient(app)


def login(c):
    r=c.post('/api/auth/login',json={'username':'admin','password':'admin123'})
    assert r.status_code==200, r.text
    return {'Authorization':'Bearer '+r.json()['access_token']}


def test_v35_expense_lifecycle_and_report():
    c=fresh_client(); h=login(c)
    r=c.post('/api/expenses',headers=h,json={
        'number':f'EXP-35-{os.getpid()}-001','date':'2026-12-29','expense_type':'إدارية',
        'description':'كهرباء المكتب','amount':1500,'expense_account_code':'5200',
        'payment_account_code':'1110','reference':'فاتورة كهرباء'
    })
    assert r.status_code==200, r.text
    eid=r.json()['id']
    r=c.post(f'/api/expenses/{eid}/post',headers=h)
    assert r.status_code==200, r.text
    assert r.json()['posted'] is True
    r=c.get('/api/reports/expenses?date_from=2026-12-01&date_to=2026-12-29',headers=h)
    assert r.status_code==200, r.text
    data=r.json(); assert data['total']==1500.0; assert data['count']==1
    r=c.get('/api/reports/profit-loss-v2?date_from=2026-12-01&date_to=2026-12-29',headers=h)
    assert r.status_code==200, r.text
    assert r.json()['expenses']==1500.0


def test_v35_expense_cannot_post_twice_or_outside_period():
    c=fresh_client(); h=login(c)
    r=c.post('/api/expenses',headers=h,json={
        'number':f'EXP-35-{os.getpid()}-002','date':'2027-01-01','expense_type':'تشغيلية',
        'description':'مصروف خارج الفترة','amount':10,'expense_account_code':'5100','payment_account_code':'1110'
    })
    assert r.status_code==200, r.text
    eid=r.json()['id']
    assert c.post(f'/api/expenses/{eid}/post',headers=h).status_code==400
    r=c.post('/api/expenses',headers=h,json={
        'number':f'EXP-35-{os.getpid()}-003','date':'2026-12-29','expense_type':'تشغيلية',
        'description':'مصروف','amount':10,'expense_account_code':'5100','payment_account_code':'1110'
    })
    assert r.status_code==200
    eid=r.json()['id']
    assert c.post(f'/api/expenses/{eid}/post',headers=h).status_code==200
    assert c.post(f'/api/expenses/{eid}/post',headers=h).status_code==409
