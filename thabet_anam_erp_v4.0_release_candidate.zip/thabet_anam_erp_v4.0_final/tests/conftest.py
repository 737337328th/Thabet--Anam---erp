import os
os.environ.setdefault('THABET_SECRET','test-secret-32-characters-long-0001')
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'backend'))
